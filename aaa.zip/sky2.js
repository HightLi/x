require('./config')
require('./menu2')
const {
	downloadContentFromMessage,
    BufferJSON,
    WA_DEFAULT_EPHEMERAL,
    generateWAMessageFromContent,
    proto,
    generateWAMessageContent,
    generateWAMessage,
    prepareWAMessageMedia,
    areJidsSameUser,
    InteractiveMessage,
    getContentType
} = require('@whiskeysockets/baileys')
const fs = require('fs')
const fsx = require('fs-extra')
const util = require('util')
const BodyForm = require('form-data')
const yts = require('yt-search')
const { fromBuffer } = require('file-type')
const chalk = require('chalk')
const { v4: uuidv4 } = require('uuid')
const { exec, spawn, execSync } = require("child_process")
const axios = require('axios')
const path = require('path')
const users = {};
const emojiRegex = /\p{Emoji}/u;
const notes = {}; // Objek untuk menyimpan catatan pengguna
const pasienSakit = {};

const obatTersedia = ['Paracetamol', 'Antibiotik', 'Vitamin C', 'Obat Pusing'];
const obatDokter = {};
const StickerXeon = JSON.parse(fs.readFileSync('./database/xeonsticker.json'))
const os = require('os')
const fetch = require('node-fetch');
const cheerio = require('cheerio');
const moment = require('moment-timezone')
const { JSDOM } = require('jsdom')
let { Image } = require('node-webpmux')
const { smims } = require('./lib/uploadImage')
const crypto = require('crypto');
const caseCount = {};
const Jimp = require('jimp');
const photooxy = require('./lib/photooxy');
const { webp2mp4File } = require('./lib/uploader')
const { mediafireDl } = require('./lib/mediafire.js')
const { fetchBuffer, GIFBufferToVideoBuffer, buffergif, pickRandom } = require("./lib/myfunc2")
const speed = require('performance-now')

const { performance } = require('perf_hooks')
const { Primbon } = require('scrape-primbon')
const anon = require('./lib/menfess')
const ytdl = require('ytdl-core')
const { addExif } = require('./lib/exif')
const primbon = new Primbon()
const { smsg, formatp, tanggal, formatDate, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins } = require('./lib/myfunc')

// read database
let tebaklagu = db.data.game.tebaklagu = []
let _family100 = db.data.game.family100 = []
let kuismath = db.data.game.math = []
let tebakgambar = db.data.game.tebakgambar = []
let tebakkata = db.data.game.tebakkata = []
let tebakbendera = db.data.game.tebakbendera = []
let caklontong = db.data.game.lontong = []
let caklontong_desk = db.data.game.lontong_desk = []
let tebakkalimat = db.data.game.kalimat = []
let tebaklirik = db.data.game.lirik = []
let tebaktebakan = db.data.game.tebakan = []
let isGameActive = false;
let isactiveFishingGames = false;
let players = null; // Daftar ID pemain dalam permainan
let impostorId = null; //ID
let secretWord = null; // Kata yang akan ditebak
let tagCount = {}; // Menyimpan jumlah tag yang telah dikirim
let tagQueue = {}; // Menyimpan antrian tag untuk setiap 
const activeGames = {};
let requiredClaps = 0;
const activeFishingGames = {};
let players1 = {};
let totalClaps = 0;
let keyQuest = {};
let conversationState = null;
let kirimpesan = true;
let registeredUsers = {};
let gameInProgress = false;
let playerAlive = true;
let intervalID
let spamCounter = {};
const adventures = [
    "Anda menemukan gua yang misterius. Apakah Anda akan masuk? (ya/tidak)",
    "Anda bertemu monster di hutan. Apakah Anda akan melawan? (ya/tidak)",
    "Anda menemukan harta karun yang tersembunyi. Apakah Anda akan mengambilnya? (ya/tidak)"
];
const chatURL = 'https://beta.character.ai/chat2?char=-p04V7wg7AT5CcJumGnEB2LVWdjvuJEfVjs1P3LOSwo';  

const results = [
    "Selamat! Anda berhasil menemukan harta yang berlimpah.",
    "Sayang sekali, Anda kalah dalam pertarungan melawan monster.",
    "Anda mendapat kutukan setelah mengambil harta karun. Sebaiknya hati-hati."
];

//DB
let { pinterest } = require('./lib/scraper');
let autosticker = JSON.parse(fs.readFileSync('./database/autosticker.json'))
let ntvirtex = JSON.parse(fs.readFileSync('./database/antivirus.json'))
let nttoxic = JSON.parse(fs.readFileSync('./database/antitoxic.json'))
let ntwame = JSON.parse(fs.readFileSync('./database/antiwame.json'))
let welcome = JSON.parse(fs.readFileSync("./database/welcome.json"));
let ntlinkgc =JSON.parse(fs.readFileSync('./database/antilinkgc.json'))
let ntlinkall =JSON.parse(fs.readFileSync('./database/antilinkall.json'))
let ntibatu =JSON.parse(fs.readFileSync('./database/antibatu.json'))
let ntiemoji =JSON.parse(fs.readFileSync('./database/antiemoji.json'))
let simion = JSON.parse(fs.readFileSync('./database/simion.json'))
let bacat = JSON.parse(fs.readFileSync('./database/bacat.json'))
let ntilinktwt =JSON.parse(fs.readFileSync('./database/antilinktwitter.json'))
let owner = JSON.parse(fs.readFileSync('./database/owner.json'))
let ntilinktt =JSON.parse(fs.readFileSync('./database/antilinktiktok.json'))
let ntilinktg =JSON.parse(fs.readFileSync('./database/antilinktelegram.json'))
let ntilinkfb =JSON.parse(fs.readFileSync('./database/antilinkfacebook.json'))
let akinator = JSON.parse(fs.readFileSync('./src/akinator.json'))
let ntilinkig =JSON.parse(fs.readFileSync('./database/antilinkinstagram.json'))
let ntilinkyt =JSON.parse(fs.readFileSync('./database/antilinkyt.json'))
const banned = JSON.parse(fs.readFileSync('./database/banned.json'))
const prem = JSON.parse(fs.readFileSync('./database/premium.json'))
module.exports = sky = async (sky, m, chatUpdate, store) => {
    try {
               const body = (m && m?.mtype) ? (
    m?.mtype === 'conversation' ? m?.message?.conversation :
    m?.mtype === 'imageMessage' ? m?.message?.imageMessage?.caption :
    m?.mtype === 'videoMessage' ? m?.message?.videoMessage?.caption :
    m?.mtype === 'extendedTextMessage' ? m?.message?.extendedTextMessage?.text :
    m?.mtype === 'buttonsResponseMessage' ? m?.message?.buttonsResponseMessage?.selectedButtonId :
    m?.mtype === 'listResponseMessage' ? m?.message?.listResponseMessage?.singleSelectReply?.selectedRowId :
    m?.mtype === 'templateButtonReplyMessage' ? m?.message?.templateButtonReplyMessage?.selectedId :
    m?.mtype === 'messageContextInfo' ? (
        m?.message?.buttonsResponseMessage?.selectedButtonId || 
        m?.message?.listResponseMessage?.singleSelectReply?.selectedRowId || 
        m?.text
    ) : ''
) : '';

        var budy = (typeof m.text == 'string' ? m.text : '')
        var prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : prefa ?? global.prefix
        global.prefix = prefix
        const isCmd = body.startsWith(prefix)
        const from = m.key.remoteJid
        const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()        
        var args = body.trim().split(/ +/).slice(1)
        var args1 = body.trim().split(/ +/).slice(1)
        args = args.concat(['','','','','',''])
        const totalFitur = () =>{
            var mytext = fs.readFileSync("./sky.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }
        const pushname = m.pushName || "No Name"
        const botNumber = await sky.decodeJid(sky.user.id)
        const isCreator = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const itsMe = m.sender == botNumber ? true : false
        const text = q = args.join(" ").trim()
        const isGroup = from.endsWith("@g.us");        
        const isBan = banned.includes(m.sender)
        const xeonymisc = (m.quoted || m)
        const quoted = (xeonymisc.mtype == 'buttonsMessage') ? xeonymisc[Object.keys(xeonymisc)[1]] : (xeonymisc.mtype == 'templateMessage') ? xeonymisc.hydratedTemplate[Object.keys(xeonymisc.hydratedTemplate)[1]] : (xeonymisc.mtype == 'product') ? xeonymisc[Object.keys(xeonymisc)[0]] : m.quoted ? m.quoted : m
        const mime = (quoted.msg || quoted).mimetype || ''
        const qmsg = (quoted.msg || quoted)
        const mentionByTag = m.sender
        const mentionByReply = m.sender
        const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
        const isMedia = /image|video|sticker|audio/.test(mime)
//GROUP
        const isAutoSticker = m.isGroup ? autosticker.includes(from) : false
        const antiVirtex = m.isGroup ? ntvirtex.includes(from) : false
        const Antilinkgc = m.isGroup ? ntlinkgc.includes(m.chat) : false
        const AntiLinkYt = m.isGroup ? ntilinkyt.includes(from) : false
        const AntiBatu = m.isGroup ? ntibatu.includes(from) : false
        const antiEmote = m.isGroup ? ntiemoji.includes(from) : false
        const SimiActive = m.isGroup ? simion.includes(from) : false
        const AntiLinkInstagram = m.isGroup ? ntilinkig.includes(from) : false
        const AntiLinkFacebook = m.isGroup ? ntilinkfb.includes(from) : false
        const AntiLinkTiktok = m.isGroup ? ntilinktt.includes(from) : false
        const bocet = m.isGroup ? bacat.includes(from) : false
        const antilinkinstagram = m.isGroup ? ntilinktg.includes(from) : false
        const AntiLinkTelegram = m.isGroup ? ntilinktg.includes(from) : false
        const isWelcome = m.isGroup ? welcome.includes(m.chat) : false;
        const AntiLinkTwitter = m.isGroup ? ntilinktwt.includes(from) : false
        const AntiLinkAll = m.isGroup ? ntlinkall.includes(from) : false
        const antiToxic = m.isGroup ? nttoxic.includes(from) : false
        const antiWame = m.isGroup ? ntwame.includes(from) : false      
        // Group
        const groupMetadata = m.isGroup ? await sky.groupMetadata(m.chat).catch(e => {}) : ''
        const groupName = m.isGroup ? groupMetadata.subject : ''         
        const participants = m.isGroup ? await groupMetadata.participants : ''
        const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
    	const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
    	const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
        const isPrem = prem.includes(m.sender)
    	const isPremium = isCreator || global.premium.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender) || false
	try {
            let isNumber = x => typeof x === 'number' && !isNaN(x)
            let limitUser = isPremium ? global.limitawal.premium : global.limitawal.free
            let BalanceUser = isPremium ? global.balanceawal.premium : global.balanceawal.free
            let user = db.data.users[m.sender];
if (typeof user !== 'object') db.data.users[m.sender] = {};
if (user) {    
    if (!isNumber(user.limit)) user.limit = limitUser;
    if (!isNumber(user.balance)) user.balance = BalanceUser;
    if (!isNumber(user.gold)) user.gold = 0;
    if (!isNumber(user.silver)) user.silver = 0;
    if (!isNumber(user.emerald)) user.emerald = 0;
    if (!isNumber(user.potion)) user.potion = 0;
} else {
    global.db.data.users[m.sender] = {
        afkTime: -1,
        afkReason: '',
        limit: limitUser,
        balance: BalanceUser,
        gold: 0,
        silver: 0,
        emerald: 0,
        potion: 0,
        premium: false
    };
}            
 // Days
        const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
        const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
        const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
        const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')


        const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if(time2 < "23:59:00"){
        var ucapanWaktu = 'Selamat Malam 🏙️'
        }
        if(time2 < "19:00:00"){
        var ucapanWaktu = 'Selamat Petang 🌆'
        }
        if(time2 < "18:00:00"){
        var ucapanWaktu = 'Selamat Sore 🌇'
        }
        if(time2 < "15:00:00"){
        var ucapanWaktu = 'Selamat Siang 🌤️'
        }
        if(time2 < "10:00:00"){
        var ucapanWaktu = 'Selamat Pagi 🌄'
        }
        if(time2 < "05:00:00"){
        var ucapanWaktu = 'Selamat Subuh 🌆'
        }
        if(time2 < "03:00:00"){
        var ucapanWaktu = 'Selamat Tengah Malam 🌃'
        }    
            let chats = db.data.chats[m.chat]
            if (typeof chats !== 'object') db.data.chats[m.chat] = {}
            if (chats) {
                if (!('mute' in chats)) chats.mute = false
                if (!('antilink' in chats)) chats.antilink = false
                if (!('antipushkontakv1' in chats)) chats.antivirtex = true
                if (!('antipushkontakv2' in chats)) chats.antivirtex = true
            } else global.db.data.chats[m.chat] = {
                mute: false,
                antilink: false,
                antipushkontakv1: false,
                antipushkontakv2: false,
            }
	    let setting = db.data.settings[botNumber]
        if (typeof setting !== 'object') db.data.settings[botNumber] = {}
	    if (setting) {
    	    if (!('anticall' in setting)) setting.anticall = true
    		if (!isNumber(setting.status)) setting.status = 0
    		if (!('autobio' in setting)) setting.autobio = false
	    } else global.db.data.settings[botNumber] = {
    	    anticall: true,
    		status: 0,
    		autobio: false
	    }
	    
        } catch (err) {
            console.error(err)
        }
	      const fkontak = {
            key: {
                participant: `0@s.whatsapp.net`,
                ...(m.chat ? {
                    remoteJid: `status@broadcast`
                } : {})
            },
            message: {
                'contactMessage': {
                    'displayName': `${pushname}`,
                    'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${botname},;;;\nFN:${botname}\nitem1.TEL;waid=${owner}:+${owner}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
                    'jpegThumbnail': thumb,
                    thumbnail: thumb,
                    sendEphemeral: true
                }   
            }
        }
        const ftroli = {key: {fromMe: false,"participant":"0@s.whatsapp.net", "remoteJid": "status@broadcast"}, "message": {orderMessage: {itemCount: 2022,status: 200, thumbnail: thumb, surface: 200, message: botname, orderTitle: "avosky", sellerJid: '0@s.whatsapp.net'}}, contextInfo: {"forwardingScore":999,"isForwarded":true},sendEphemeral: true}
        
 if (m.chat.endsWith('@s.whatsapp.net') && !isCmd) {
let room = Object.values(anon.anonymous).find(p => p.state == "CHATTING" && p.check(sender))
if (room) {
let other = room.other(sender)
m.copyNForward(other, true, m.quoted && m.quoted.fromMe ? {
contextInfo: {
...m.msg.contextInfo,
forwardingScore: 0,
isForwarded: true,
participant: other
}
} : {})
}
}
//SENDBUTTON
function sendButton(chatId, text, buttonText, buttonId) {
    let { proto, generateWAMessageFromContent } = require('@whiskeysockets/baileys');
    
    let msg = generateWAMessageFromContent(chatId, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: text
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: `© avosky`
                    }), 
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                "name": "quick_reply",
                                "buttonParamsJson": `{"display_text":"${buttonText}","id":"${buttonId}"}`
                            }
                        ]
                    })
                })
            }
        }
    }, {});

    sky.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
}
function randomNomor(min, max = null){
if (max !== null) {
min = Math.ceil(min);
max = Math.floor(max);
return Math.floor(Math.random() * (max - min + 1)) + min;
} else {
return Math.floor(Math.random() * min) + 1
}
}
//
const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}
        // Public & Self
        if (!sky.public) {
            if (!m.key.fromMe) return
        } 
const downloadMp4 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp4File = getRandom('.mp4')
console.log(color('Download Video With ytdl-core'))
let nana = ytdl(Link)
.pipe(fs.createWriteStream(mp4File))
.on('finish', async () => {
await sky.sendMessage(from, { video: fs.readFileSync(mp4File), gifPlayback: false }, { quoted: m })
fs.unlinkSync(`./${mp4File}`)
})
} catch (err) {
reply(`${err}`)
}
}

const downloadMp3 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp3File = getRandom('.mp3')
console.log(color('Download Audio With ytdl-core'))
ytdl(Link, { filter: 'audioonly' })
.pipe(fs.createWriteStream(mp3File))
.on('finish', async () => {
await sky.sendMessage(from, { audio: fs.readFileSync(mp3File), mimetype: 'audio/mp4' }, { quoted: m })
fs.unlinkSync(mp3File)
})
} catch (err) {
reply(`${err}`)
}
}
//gif
async function sendGif(url, chatId, caption) {
    try {
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(response.data, "utf-8");
        const fetchedgif = await GIFBufferToVideoBuffer(buffer);

        await sky.sendMessage(chatId, { video: fetchedgif, gifPlayback: true }, { quoted: m, caption: caption });
    } catch (error) {
        console.log(error);
    }
}

function sendLiveLocation(to, locationData, duration, options = {}) {
    const msg = {
        location: locationData,
        liveLocation: true,
        liveDuration: duration
    };
    sky.sendMessage(to, msg, options);
}

function sendOTP(number) {
  const otp = Math.floor(1000 + Math.random() * 9000);
  registeredUsers[number] = { otp };
    sky.sendText(sender, `OTP untuk ${number}: ${otp}`);
}
//ADDG
async function jarak(from, to) {
	let html = (await axios(`https://www.google.com/search?q=${encodeURIComponent('jarak ' + from + ' to ' + to)}&hl=id`)).data
	let $ = cheerio.load(html), obj = {}
	let img = html.split("var s=\'")?.[1]?.split("\'")?.[0]
	obj.img = /^data:.*?\/.*?;base64,/i.test(img) ? Buffer.from(img.split`,` [1], 'base64') : ''
	obj.desc = $('div.BNeawe.deIvCb.AP7Wnd').text()?.trim()
	return obj
}
async function loading () {
var hawemod = [
"🟨🟨🟨🟨🟨🟨🟨🟨",
"🟨🟦🟦🔲🔲🟦🟦🟨",
"🏽🏽🏽🏽🏽🏽🏽🏽",
"🏽⬜🟦🏽🏽🟦⬜🏽",
"🏽🏽🏽🏽🏽🏽🏽🏽",
"🏽🏽🟫🏽🏽🟫🏽🏽",
"🏽🏽🟫🟫🟫🟫🏽🏽",
"NARUTO",
]
let { key } = await sky.sendMessage(from, {text: 'ʟᴏᴀᴅɪɴɢ...'})//Pengalih isu

for (let i = 0; i < hawemod.length; i++) {
/*await delay(10)*/
await sky.sendMessage(from, {text: hawemod[i], edit: key });//PESAN LEPAS
}
}
async function skysend(chatId, message, options = {}){
    let generate = await generateWAMessage(chatId, message, options)
    let type2 = getContentType(generate.message)
    if ('contextInfo' in options) generate.message[type2].contextInfo = options?.contextInfo
    if ('contextInfo' in message) generate.message[type2].contextInfo = message?.contextInfo
    return await sky.relayMessage(chatId, generate.message, { messageId: generate.key.id })
}
async function getLatestAnime() {
  try {
    const response = await axios.get('https://myanimelist.net/anime/season');
    const $ = cheerio.load(response.data);
    
    const animeList = [];
    
    $('div.seasonal-anime').each((index, element) => {
      const title = $(element).find('div.title-text').text().trim();
      const link = $(element).find('div.title-text a').attr('href');
      
      if (title && link) {
        animeList.push({ title, link });
      }
    });
    
    return animeList;
  } catch (error) {
    console.error('Error fetching latest anime:', error);
    return [];
  }
}
let list = []
for (let i of owner) {
list.push({
	    	displayName: await sky.getName(i),
	    	vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await sky.getName(i)}\nFN:${await sky.getName(i)}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Click here to chat\nitem2.EMAIL;type=INTERNET:${ytname}\nitem2.X-ABLabel:YouTube\nitem3.URL:${socialm}\nitem3.X-ABLabel:GitHub\nitem4.ADR:;;${location};;;;\nitem4.X-ABLabel:Region\nEND:VCARD`
	    })
	}
async function getLatestBBCNews() {
  try {
    const response = await axios.get('https://www.bbc.co.uk/news');
    const $ = cheerio.load(response.data);
    
    const news = [];
    
    $('div.gs-c-promo').each((index, element) => {
      const title = $(element).find('h3').text();
      const link = $(element).find('a').attr('href');
      
      if (title && link) {
        news.push({ title, link });
      }
    });
    
    return news;
  } catch (error) {
    console.error('Error fetching BBC news:', error);
    return [];
  }
}
async function performAdvancedBugHunting(url) {
    try {
        const response = await axios.get(url);
        const $ = cheerio.load(response.data);

        const headers = response.headers;
        const status = response.status;
        const contentType = headers['content-type'];

        // Check for insecure HTTP resources
        const insecureResources = [];
        $('*[src^="http://"]').each((index, element) => {
            insecureResources.push($(element).attr('src'));
        });

        // Check for forms without secure attribute
        const formsWithoutSecure = $('form:not([method="post"])');

        // More vulnerability checks can be added here

        const report = `Laporan Bug Hunting untuk ${url}:\nStatus: ${status}\nTipe Konten: ${contentType}\nCek Sumber Tidak Aman\n${insecureResources.join('\n')}\nFormulir Tanpa Atribut Aman\n${formsWithoutSecure.length} formulir tanpa atribut "method" yang aman`;

        return report;
    } catch (error) {
        throw 'Gagal melakukan Bug Hunting.';
    }
}
// Function to fetch quotes from URL
function quotes(input) {
    return new Promise((resolve, reject) => {
        fetch('https://jagokata.com/kata-bijak/kata-' + input.replace(/\s/g, '_') + '.html?page=1')
            .then(res => res.text())
            .then(res => {
                const $ = cheerio.load(res);
                data = [];
                $('div[id="main"]').find('ul[id="citatenrijen"] > li').each(function (index, element) {
                    x = $(this).find('div[class="citatenlijst-auteur"] > a').text().trim();
                    y = $(this).find('span[class="auteur-beschrijving"]').text().trim();
                    z = $(element).find('q[class="fbquote"]').text().trim();
                    data.push({ author: x, bio: y, quote: z });
                });
                data.splice(2, 1);
                if (data.length == 0) return resolve({ creator: '@neoxr - Wildan Izzudin & @ariffb.id - Ariffb', status: false });
                resolve({ creator: '@skyyyy', status: true, data });
            }).catch(reject);
    });
}
async function getIpInfo(ip) {
    try {
        const response = await axios.get(`https://ipinfo.io/${ip}/json`);
        return response.data;
    } catch (error) {
        throw 'Gagal mendapatkan informasi IP.';
    }
}
const replygc = (teks) => {
    sky.sendMessage(from, { 
        text: teks, 
        contextInfo: {
            mentionedJid: [],
            groupMentions: [],
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '0@newsletter',
                newsletterName: "avosky-md",
                serverMessageId: -1
            },
            forwardingScore: 256,
            externalAdReply: {
                showAdAttribution: true,
                title: `avoskh-md`,
                body: `alaaaaooooooo`,
                thumbnailUrl: `avosky.com`,
                sourceUrl: "https://wa.me/33451220170",
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m })
}
	// auto set bio
	if (db.data.settings[botNumber].autobio) {
	    let setting = global.db.data.settings[botNumber]
	    if (new Date() * 1 - setting.status > 1000) {
		let uptime = await runtime(process.uptime())
		await sky.updateProfileStatus(`${sky.user.name} | Runtime : ${runtime(uptime)}`)
		setting.status = new Date() * 1
	    }
	}
	async function waitForMessage(from, regex, timeout) {
    return new Promise(async (resolve) => {
        const startTime = Date.now();

        while (Date.now() - startTime < timeout) {
            const messages = await sky.sendMessage(m.chat, { fromMe: false })
            
            for (const message of messages) {
                if (message.sender === from && regex.test(message.content)) {
                    resolve(message);
                    return;
                }
            }

            await new Promise(resolve => setTimeout(resolve, 1000)); // Tunggu selama 1 detik sebelum cek kembali
        }

        resolve(null); // Timeout tercapai
    });
}
function formatSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function sizeLimit(size, limit) {
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const limitSize = parseFloat(limit);
  const limitUnit = limit.replace(/[\d.]/g, '');
  const limitIndex = sizes.findIndex(unit => unit === limitUnit);
  const currentSize = parseFloat(size);
  const currentUnit = size.replace(/[\d.]/g, '');
  const currentIndex = sizes.findIndex(unit => unit === currentUnit);

  if (currentIndex > limitIndex) {
    return {
      oversize: true,
      currentSize: currentSize,
      currentUnit: currentUnit,
      limitSize: limitSize,
      limitUnit: limitUnit
    };
  } else {
    return {
      oversize: false,
      currentSize: currentSize,
      currentUnit: currentUnit,
      limitSize: limitSize,
      limitUnit: limitUnit
    };
  }
}

function jsonFormat(json) {
  return JSON.stringify(json, null, 2);
}
async function replyprem(teks) {
    m.reply(`sorry fitur ini hanya untuk premium only jika ingin premium bisa ketik .buyprem`)
}	
async function sendNextTag(user) {
  if (tagQueue[user] && tagQueue[user].currentIndex < tagQueue[user].amount) {
    const target = tagQueue[user].target;
    const currentIndex = tagQueue[user].currentIndex;

    // Mengirim tag berikutnya
    sky.sendTextWithMentions(from, `${target}`);
    
    // Menambahkan 1 ke currentIndex dan menjalankan pengiriman tag selanjutnya setelah jeda
    tagQueue[user].currentIndex++;
    setTimeout(() => {
      sendNextTag(user);
    }, 1000); // Jeda 1 detik
  } else {
    // Menghapus antrian tag setelah selesai
    delete tagQueue[user];
  }
}  
// Fungsi untuk mengacak urutan elemen dalam array
function shuffleArray(array) {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}
function drawCard() {
    const cards = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    const randomIndex = Math.floor(Math.random() * cards.length);
    return cards[randomIndex];
}

function calculateScore(hand) {
    let score = 0;
    let numOfAces = 0;

    for (let card of hand) {
        if (card === 'A') {
            numOfAces++;
            score += 11;
        } else if (['K', 'Q', 'J'].includes(card)) {
            score += 10;
        } else {
            score += parseInt(card);
        }
    }

    while (numOfAces > 0 && score > 21) {
        score -= 10;
        numOfAces--;
    }

    return score;
}

	        // Autosticker gc
        if (isAutoSticker) {
            if (/image/.test(mime) && !/webp/.test(mime)) {
                let mediac = await quoted.download()
                await sky.sendImageAsSticker(from, mediac, m, { packname: global.packname, author: global.author })
                console.log(`Auto sticker detected`)
            } else if (/video/.test(mime)) {
                if ((quoted.msg || quoted).seconds > 11) return
                let mediac = await quoted.download()
                await sky.sendVideoAsSticker(from, mediac, m, { packname: global.packname, author: global.author })
            }
        }
    if (antiEmote) {
    if (emojiRegex.test(budy)) {
        if (!isBotAdmins) return
bcl = `Admin Bebas Emoji`
if (isAdmins) return m.reply(bcl)
if (m.key.fromMe) return m.reply(bcl)
kice = m.sender
            await sky.sendMessage(m.chat, {
               delete: {
                  remoteJid: m.chat,
                  fromMe: false,
                  id: m.key.id,
                  participant: m.key.participant
               }
            })             	
sky.sendMessage(from, {text:`Sorry ${pushname} No Emoji here `, contextInfo:{mentionedJid:[kice]}}, {quoted:m})
} else {
}
}
           
    if (bocet) {
if (isGroup && bocet && !isPrem && !itsMe && !isCreator) return 
}
         if (AntiBatu)
         if (budy.match("🗿")) {
         if (!isBotAdmins) return
bcl = `「 Admin Kan Bebas 🗿 」 `
if (isAdmins) return m.reply(bcl)
if (m.key.fromMe) return m.reply(bcl)
kice = m.sender
            await sky.sendMessage(m.chat, {
               delete: {
                  remoteJid: m.chat,
                  fromMe: false,
                  id: m.key.id,
                  participant: m.key.participant
               }
            })             	
sky.sendMessage(from, {text:`\`\`\`「 🗿 Detected 」\`\`\`\n\n@${kice.split("@")[0]} His Anti Stone Message Has Been Deleted`, contextInfo:{mentionedJid:[kice]}}, {quoted:m})
} else {
}
 // Antiwame by xeon
  if (antiWame)
  if (budy.includes("wa.me","Wa.me")) {
if (!isBotAdmins) return 
bvl = `\`\`\`「 Wa.me Link Detected 」\`\`\`\n\nAdmin has sent a wa.me link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
kice = m.sender
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Wa.me Link Detected 」\`\`\`\n\n@${kice.split("@")[0]} Has been kicked because of sending wa.me link in this group`, contextInfo:{mentionedJid:[kice]}}, {quoted:m})
} else {
}
         //Anti Link Push kontakV1
        if (db.data.chats[m.chat].antipushkontakv1) {
            if (budy.match(`pushkontak`)) {
                m.reply(`「 ANTI PUSH KONTAK 」\n\nKamu Terdeteksi Sedang Push kontak, Anak Yatim Lagi Push kontak 😂 !`)
                if (!isBotAdmins) return m.reply(`Ehh Bot Gak Admin T_T`)
                if (isAdmins) return m.reply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return m.reply(`Ehh Maaf Kamu Ownerku Ternyata 😅`)
                sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            }
        }
        //SKYY
     //Anti Promosi
        if (db.data.chats[m.chat].antipushkontakv2) {
            if (budy.match(`panel`)) {
                m.reply(`「 ANTI PROMOSI 」\n\nKamu Terdeteksi Sedang Promosi, Anak Yatim Lagi Promosi 😂 !`)
                if (!isBotAdmins) return m.reply(`Ehh Bot Gak Admin T_T`)
                if (isAdmins) return m.reply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return m.reply(`Ehh Maaf Kamu Ownerku Ternyata 😅`)
                sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            }
        }
// Anti Link
        if (Antilinkgc) {
        if (budy.match(`chat.whatsapp.com`)) {
        if (!isBotAdmins) return mess.botAdmin
        let gclink = (`https://chat.whatsapp.com/`+await sky.groupInviteCode(m.chat))
        let isLinkThisGc = new RegExp(gclink, 'i')
        let isgclink = isLinkThisGc.test(m.text)
        if (isgclink) return sky.sendMessage(m.chat, {text: `\`\`\`「 Group Link Detected 」\`\`\`\n\nYou won't be kicked by a bot because what you send is a link to this group`})
        if (isAdmins) return sky.sendMessage(m.chat, {text: `\`\`\`「 Group Link Detected 」\`\`\`\n\nAdmin has sent a link, admin is free to post any link`})
        
        kice = m.sender
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
			sky.sendMessage(from, {text:`\`\`\`「 Group Link Detected 」\`\`\`\n\n@${kice.split("@")[0]} Has been kicked because of sending group link in this group`, contextInfo:{mentionedJid:[kice]}}, {quoted:m})
            }            
        }
//antivirtex by xeon
  if (antiVirtex) {
  if (budy.length > 3500) {
  if (!isBotAdmins) return mess.botAdmin
          await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
			sky.sendMessage(from, {text:`\`\`\`「 Virus Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending virus in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
  }
  }
//anti bad words by xeon
if (antiToxic)
if (BadXeon.includes(messagesD)) {
if (m.text) {
bvl = `\`\`\`「 Bad Word Detected 」\`\`\`\n\nYou are using bad word but you are an admin/owner that's why i won't kick you😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			await sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Bad Word Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} was kicked because of using bad words in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})}
}
//antilink youtube video by xeon
if (AntiLinkYt)
if (budy.includes("https://youtu.be/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 YoutTube Video Link Detected 」\`\`\`\n\nAdmin has sent a youtube video link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 YouTube Video Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending youtube video link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink instagram by xeon
if (AntiLinkInstagram)
   if (budy.includes("https://www.instagram.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Instagram Link Detected 」\`\`\`\n\nAdmin has sent a instagram link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Instagram Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending instagram link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink facebook by xeon
if (AntiLinkFacebook)
   if (budy.includes("https://facebook.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Facebook Link Detected 」\`\`\`\n\nAdmin has sent a facebook link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Facebook Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending facebook link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink telegram by xeon
if (AntiLinkTelegram)
   if (budy.includes("https://t.me/")){
if (AntiLinkTelegram)
if (!isBotAdmins) return
bvl = `\`\`\`「 Telegram Link Detected 」\`\`\`\n\nAdmin has sent a telegram link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Telegram Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending telegram link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink tiktok by xeon
if (AntiLinkTiktok)
   if (budy.includes("https://www.tiktok.com/","https://vt.tiktok.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Tiktok Link Detected 」\`\`\`\n\nAdmin has sent a tiktok link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Tiktok Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending tiktok link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink twitter by xeon
if (AntiLinkTwitter)
   if (budy.includes("https://twitter.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Twitter Link Detected 」\`\`\`\n\nAdmin has sent a twitter link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Tiktok Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending twitter link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
 // Akinator Setting Start
 
	if (akinator.hasOwnProperty(m.sender.split('@')[0]) && isCmd && ["0", "1", "2", "3", "4", "5"].includes(body)) {
                kuis = true
                var { server, frontaddr, session, signature, question, step } = akinator[m.sender.split('@')[0]]
                if (step == "0" && budy == "5") throw("Maaf Anda telah mencapai pertanyaan pertama")
                var ini_url = `https://api.lolhuman.xyz/api/akinator/answer?apikey=Gata_Dios&server=${server}&frontaddr=${frontaddr}&session=${session}&signature=${signature}&answer=${budy}&step=${step}`
                var get_result = await fetchJson(ini_url)
                var get_result = get_result.result
                if (get_result.hasOwnProperty("name")) {
                    var ini_name = get_result.name
                    var description = get_result.description
                    ini_txt = `${ini_name} - ${description}\n\n`
                    ini_txt += "Apakah Tebakan Saya Benar? Tuan/Nyonya\n\nSekian dan terima gaji. Akinator by Avosky-MD"
                    await sky.sendImage(m.chat, get_result.image, ini_txt, m).then(() => {
                        delete akinator[m.sender.split('@')[0]]
                        fs.writeFileSync("./src/akinator.json", JSON.stringify(akinator))
                    })
                    return
                }
                var { question, _, step } = get_result
                ini_txt = `🤔🤔\n${question}\n\n`
                ini_txt += "0 - Ya\n"
                ini_txt += "1 - Tidak\n"
                ini_txt += "2 - Saya Tidak Tau\n"
                ini_txt += "3 - Mungkin\n"
                ini_txt += "4 - Mungkin Tidak\n"
                ini_txt += "5 - Kembali ke Pertanyaan Sebelumnya"
                if (args[0] === '5') {
                    var ini_url = `https://api.lolhuman.xyz/api/akinator/back?apikey=Gata_Dios&server=${server}&frontaddr=${frontaddr}&session=${session}&signature=${signature}&answer=${budy}&step=${step}`
                    var get_result = await fetchJson(ini_url)
                    var get_result = get_result.result
                    var { question, _, step } = get_result
                    ini_txt = `🤔🤔\n${question}\n\n`
                    ini_txt += "0 - Ya\n"
                    ini_txt += "1 - Tidak\n"
                    ini_txt += "2 - Saya Tidak Tau\n"
                    ini_txt += "3 - Mungkin\n"
                    ini_txt += "4 - Mungkin Tidak"
                    ini_txt += "5 - Kembali ke Pertanyaan Sebelumnya"
                }
                sky.sendText(m.chat, ini_txt, m).then(() => {
                    const data_ = akinator[m.sender.split('@')[0]]
                    data_["question"] = question
                    data_["step"] = step
                    akinator[m.sender.split('@')[0]] = data_
                    fs.writeFileSync("./src/akinator.json", JSON.stringify(akinator))
                })
            }
			
 // Akinator settings end
//antilink all by xeon
if (AntiLinkAll)
   if (budy.includes("https://")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Link Detected 」\`\`\`\n\nAdmin has sent a link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
      // Mute Chat
      if (db.data.chats[m.chat].mute && !isAdmins && !isCreator) {
      return
      }
// GAME 
function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function formatNumber(number) {
  return number.toLocaleString();
}

// Panggil fungsi handleBombGame di tempat yang sesuai dalam handler pesan bot Anda.
	    
 
	if (('family100'+m.chat in _family100) && isCmd) {
            kuis = true
            let room = _family100['family100'+m.chat]
            let teks = budy.toLowerCase().replace(/[^\w\s\-]+/, '')
            let isSurender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
            if (!isSurender) {
                let index = room.jawaban.findIndex(v => v.toLowerCase().replace(/[^\w\s\-]+/, '') === teks)
                if (room.terjawab[index]) return !0
                room.terjawab[index] = m.sender
            }
            let isWin = room.terjawab.length === room.terjawab.filter(v => v).length
            let caption = `
Jawablah Pertanyaan Berikut :\n${room.soal}\n\n\nTerdapat ${room.jawaban.length} Jawaban ${room.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}
${isWin ? `Semua Jawaban Terjawab` : isSurender ? 'Menyerah!' : ''}
${Array.from(room.jawaban, (jawaban, index) => {
        return isSurender || room.terjawab[index] ? `(${index + 1}) ${jawaban} ${room.terjawab[index] ? '@' + room.terjawab[index].split('@')[0] : ''}`.trim() : false
    }).filter(v => v).join('\n')}
    ${isSurender ? '' : `Perfect Player`}`.trim()
            sky.sendText(m.chat, caption, m, { contextInfo: { mentionedJid: parseMention(caption) }}).then(mes => { return _family100['family100'+m.chat].pesan = mesg }).catch(_ => _)
            if (isWin || isSurender) delete _family100['family100'+m.chat]
        }
        if (kuismath.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = kuismath[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                await m.reply(`🎮 Kuis Matematika  🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`)
                delete kuismath[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }

        if (tebakgambar.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebakgambar[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                    const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah;
                await m.reply(`🎮 Tebak Gambar 🎮\n\nJawaban Benar 🎉\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance`)
                delete tebakgambar[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }        					
if (tebakkata.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
    kuis = true
    jawaban = tebakkata[m.sender.split('@')[0]]
    if (budy.toLowerCase() == jawaban) {
        const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
        await m.reply(`🎮 Tebak Kata 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`);
        delete tebakkata[m.sender.split('@')[0]];
    } else {
        m.reply('*Jawaban Salah!*');
    }
}
if (tebakbendera.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
    kuis = true
    jawaban = tebakbendera[m.sender.split('@')[0]]
    if (budy.toLowerCase() == jawaban) {
        const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
        await m.reply(`🎮 Tebak Bendera 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`);
        delete tebakbendera[m.sender.split('@')[0]];
    } else {
        m.reply('*Jawaban Salah!*');
    }
}
        if (caklontong.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = caklontong[m.sender.split('@')[0]]
	    deskripsi = caklontong_desk[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                    const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
                await m.reply(`🎮 Cak Lontong 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`)
                delete caklontong[m.sender.split('@')[0]]
		delete caklontong_desk[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }

        if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebakkalimat[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                    const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
                await m.reply(`🎮 Tebak Kalimat 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`)
                delete tebakkalimat[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }

        if (tebaklirik.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebaklirik[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                    const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
                await m.reply(`🎮 Tebak Lirik 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`)
                delete tebaklirik[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }
	    
	if (tebaktebakan.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebaktebakan[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                                const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
                await m.reply(`🎮 Tebak Tebakan 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`)
                delete tebaktebakan[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }
     //tuctac2
const TicTacToeBot = require("./lib/TicTacToeBot");
let tttGames = {};

function getTTTGame(chatId) {
    if (!(chatId in tttGames)) {
        tttGames[chatId] = {
            board: Array(9).fill(null),
            bot: new TicTacToeBot(),
            isBotTurn: false
        };
    }
    return tttGames[chatId];
}
        //TicTacToe
	    this.game = this.game ? this.game : {}
	    let room = Object.values(this.game).find(room => room.id && room.game && room.state && room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender) && room.state == 'PLAYING')
	    if (room) {
	    let ok
	    let isWin = !1
	    let isTie = !1
	    let isSurrender = !1
	    // m.reply(`[DEBUG]\n${parseInt(m.text)}`)
	    if (!/^([1-9]|(me)?nyerah|surr?ender|off|skip)$/i.test(m.text)) return
	    isSurrender = !/^[1-9]$/.test(m.text)
	    if (m.sender !== room.game.currentTurn) { // nek wayahku
	    if (!isSurrender) return !0
	    }
	    if (!isSurrender && 1 > (ok = room.game.turn(m.sender === room.game.playerO, parseInt(m.text) - 1))) {
	    m.reply({
	    '-3': 'Game telah berakhir',
	    '-2': 'Invalid',
	    '-1': 'Posisi Invalid',
	    0: 'Posisi Invalid',
	    }[ok])
	    return !0
	    }
	    if (m.sender === room.game.winner) isWin = true
	    else if (room.game.board === 511) isTie = true
	    let arr = room.game.render().map(v => {
	    return {
	    X: '❌',
	    O: '⭕',
	    1: '1️⃣',
	    2: '2️⃣',
	    3: '3️⃣',
	    4: '4️⃣',
	    5: '5️⃣',
	    6: '6️⃣',
	    7: '7️⃣',
	    8: '8️⃣',
	    9: '9️⃣',
	    }[v]
	    })
	    if (isSurrender) {
	    room.game._currentTurn = m.sender === room.game.playerX
	    isWin = true
	    }
	    let winner = isSurrender ? room.game.currentTurn : room.game.winner
	    let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `@${winner.split('@')[0]} Menang!` : isTie ? `Game berakhir` : `Giliran ${['❌', '⭕'][1 * room.game._currentTurn]} (@${room.game.currentTurn.split('@')[0]})`}
❌: @${room.game.playerX.split('@')[0]}
⭕: @${room.game.playerO.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
	    if ((room.game._currentTurn ^ isSurrender ? room.x : room.o) !== m.chat)
	    room[room.game._currentTurn ^ isSurrender ? 'x' : 'o'] = m.chat
	    if (room.x !== room.o) await sky.sendText(room.x, str, m, { mentions: parseMention(str) } )
	    await sky.sendText(room.o, str, m, { mentions: parseMention(str) } )
	    if (isTie || isWin) {
	    delete this.game[room.id]
	    }
	    }

        //Suit PvP
	    this.suit = this.suit ? this.suit : {}
	    let roof = Object.values(this.suit).find(roof => roof.id && roof.status && [roof.p, roof.p2].includes(m.sender))
	    if (roof) {
	    let win = ''
	    let tie = false
	    if (m.sender == roof.p2 && /^(acc(ept)?|terima|gas|oke?|tolak|gamau|nanti|ga(k.)?bisa|y)/i.test(m.text) && m.isGroup && roof.status == 'wait') {
	    if (/^(tolak|gamau|nanti|n|ga(k.)?bisa)/i.test(m.text)) {
	    sky.sendTextWithMentions(m.chat, `@${roof.p2.split`@`[0]} menolak suit, suit dibatalkan`, m)
	    delete this.suit[roof.id]
	    return !0
	    }
	    roof.status = 'play'
	    roof.asal = m.chat
	    clearTimeout(roof.waktu)
	    //delete roof[roof.id].waktu
	    sky.sendText(m.chat, `Suit telah dikirimkan ke chat

@${roof.p.split`@`[0]} dan 
@${roof.p2.split`@`[0]}

Silahkan pilih suit di chat masing"
klik https://wa.me/${botNumber.split`@`[0]}`, m, { mentions: [roof.p, roof.p2] })
	    if (!roof.pilih) sky.sendText(roof.p, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
	    if (!roof.pilih2) sky.sendText(roof.p2, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
	    roof.waktu_milih = setTimeout(() => {
	    if (!roof.pilih && !roof.pilih2) sky.sendText(m.chat, `Kedua pemain tidak niat main,\nSuit dibatalkan`)
	    else if (!roof.pilih || !roof.pilih2) {
	    win = !roof.pilih ? roof.p2 : roof.p
	    sky.sendTextWithMentions(m.chat, `@${(roof.pilih ? roof.p2 : roof.p).split`@`[0]} tidak memilih suit, game berakhir`, m)
	    }
	    delete this.suit[roof.id]
	    return !0
	    }, roof.timeout)
	    }
	    let jwb = m.sender == roof.p
	    let jwb2 = m.sender == roof.p2
	    let g = /gunting/i
	    let b = /batu/i
	    let k = /kertas/i
	    let reg = /^(gunting|batu|kertas)/i
	    if (jwb && reg.test(m.text) && !roof.pilih && !m.isGroup) {
	    roof.pilih = reg.exec(m.text.toLowerCase())[0]
	    roof.text = m.text
	    m.reply(`Kamu telah memilih ${m.text} ${!roof.pilih2 ? `\n\nMenunggu lawan memilih` : ''}`)
	    if (!roof.pilih2) sky.sendText(roof.p2, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
	    }
	    if (jwb2 && reg.test(m.text) && !roof.pilih2 && !m.isGroup) {
	    roof.pilih2 = reg.exec(m.text.toLowerCase())[0]
	    roof.text2 = m.text
	    m.reply(`Kamu telah memilih ${m.text} ${!roof.pilih ? `\n\nMenunggu lawan memilih` : ''}`)
	    if (!roof.pilih) sky.sendText(roof.p, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
	    }
	    let stage = roof.pilih
	    let stage2 = roof.pilih2
	    if (roof.pilih && roof.pilih2) {
	    clearTimeout(roof.waktu_milih)
	    if (b.test(stage) && g.test(stage2)) win = roof.p
	    else if (b.test(stage) && k.test(stage2)) win = roof.p2
	    else if (g.test(stage) && k.test(stage2)) win = roof.p
	    else if (g.test(stage) && b.test(stage2)) win = roof.p2
	    else if (k.test(stage) && b.test(stage2)) win = roof.p
	    else if (k.test(stage) && g.test(stage2)) win = roof.p2
	    else if (stage == stage2) tie = true
	    sky.sendText(roof.asal, `_*Hasil Suit*_${tie ? '\nSERI' : ''}

@${roof.p.split`@`[0]} (${roof.text}) ${tie ? '' : roof.p == win ? ` Menang \n` : ` Kalah \n`}
@${roof.p2.split`@`[0]} (${roof.text2}) ${tie ? '' : roof.p2 == win ? ` Menang \n` : ` Kalah \n`}
`.trim(), m, { mentions: [roof.p, roof.p2] })
	    delete this.suit[roof.id]
	    }
	    }
	    
	    let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
	    for (let jid of mentionUser) {
            let user = global.db.data.users[jid]
            if (!user) continue
            let afkTime = user.afkTime
            if (!afkTime || afkTime < 0) continue
            let reason = user.afkReason || ''
            m.reply(`
Jangan tag dia!
Dia sedang AFK ${reason ? 'dengan alasan ' + reason : 'tanpa alasan'}
Selama ${clockString(new Date - afkTime)}
`.trim())
        }

        if (db.data.users[m.sender].afkTime > -1) {
            let user = global.db.data.users[m.sender]
            sky.sendTextWithMentions(m.chat, `@${m.sender.split('@')[0]} berhenti AFK${user.afkReason ? ' setelah ' + user.afkReason : ''}
Selama ${clockString(new Date - user.afkTime)}`)
            user.afkTime = -1
            user.afkReason = ''
        }	    
        switch(command) {
	    // CASE DI SINI
case 'addcase2': {
    if (!isCreator) {
        m.reply('Anda tidak memiliki izin untuk menambahkan case baru.');
        return;
    }
    if (!text) {
        m.reply('Silakan masukkan isi case.');
        return;
    }
    
    const cases = fs.readFileSync('sky2.js').toString();
    const caseBody = text;
    const caseName = caseBody.match(/case '(.*?)':/)[1]; // Mendapatkan nama case dari teks case baru
    
    // Cari apakah case dengan nama yang sama sudah ada
    const startIndex = cases.indexOf(`case '${caseName}':`);
    if (startIndex !== -1) {
        // Jika ditemukan, hapus case lama sebelum menambahkan yang baru
        const endIndex = cases.indexOf('break', startIndex) + 6; // +6 untuk memasukkan break;
        const updatedCases = cases.slice(0, startIndex) + caseBody + '\n' + cases.slice(endIndex);
        fs.writeFileSync('sky2.js', updatedCases);
        m.reply(`Case '${caseName}' berhasil diperbarui.`);
    } else {
        // Jika tidak ditemukan, tambahkan case baru di akhir file seperti sebelumnya
        const indexOfBreak = cases.lastIndexOf('//ADDF');
        if (indexOfBreak === -1) {
            m.reply('Terjadi kesalahan dalam menemukan tempat untuk menambahkan case.');
            return;
        }
        const newCase = `${caseBody}\n`;
        const updatedCases = cases.slice(0, indexOfBreak) + newCase + cases.slice(indexOfBreak);
        fs.writeFileSync('sky2.js', updatedCases);
        m.reply('Case baru berhasil ditambahkan!');
    }
    }
    break
    case 'deletecase2': {
    if (!isCreator) {
        m.reply('Anda tidak memiliki izin untuk menghapus case.');
        return;
    }

    if (!text) {
        m.reply('Silakan masukkan nama case yang ingin dihapus.');
        return;
    }

    const cases = fs.readFileSync('sky2.js').toString();
    const caseNameToDelete = text;
    const startIndex = cases.indexOf(`case '${caseNameToDelete}':`);

    if (startIndex === -1) {
        m.reply(`Case '${caseNameToDelete}' tidak ditemukan.`);
        return;
    }

    const endIndex = cases.indexOf('break', startIndex);

    if (endIndex === -1) {
        m.reply('Terjadi kesalahan dalam menemukan titik "break;" dalam kode.');
        return;
    }

    // Menghapus hanya bagian case sampai break saja
    const updatedCases = cases.slice(0, startIndex) + cases.slice(endIndex + 6);
    fs.writeFileSync('sky2.js', updatedCases);
    m.reply(`Bagian case '${caseNameToDelete}' berhasil dihapus.`);
    }
    break;	    


case 'listcase2': {
 const fs = require('fs');
 try {
 const mytext = fs.readFileSync('./sky2.js', 'utf8');
 const cases = mytext.match(/case '.*?':/g);
 if (cases) {
 const sortedCases = cases
 .map((caseString) => caseString.replace(/case |:/g, ''))
 .sort();
 const listMessage = `Daftar Case:\n${sortedCases.join('\n')}`;
 m.reply(listMessage);
 } else {
 m.reply('Tidak ada case yang ditemukan dalam file sky2.js.');
 }
 } catch (error) {
 m.reply('Terjadi kesalahan saat mencoba membaca file sky2.js.');
 }
}
break
case 'generateimg': {
 const axios = require('axios');

 async function generateImages(prompt, model) {
 try {
 const randomIP = `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
 const userAgentList = [
 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Safari/605.1.15',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
 'Mozilla/5.0 (Linux; Android 10; SM-G960U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Mobile Safari/537.36'
 ];
 const randomUserAgent = userAgentList[Math.floor(Math.random() * userAgentList.length)];
 const ngenloot = await axios.post(
 'https://restapi.cutout.pro/web/ai/generateImage/generateAsync',
 {
 prompt: prompt,
 style: model,
 quantity: 3,
 width: 512,
 height: 512
 },
 {
 headers: {
 "Content-Type": "application/json",
 "User-Agent": randomUserAgent,
 "X-Forwarded-For": randomIP,
 "Referer": "https://www.cutout.pro/zh-CN/ai-art-generation/upload"
 }
 }
 );

 if (!ngenloot.data.data || !ngenloot.data.data.batchId) {
 throw new Error(`无法从 POST 响应中检索 batchId ${model}`);
 }
 const batchId = ngenloot.data.data.batchId;
 let kentod_asli = false;
 let nganu_hasil = [];
 while (!kentod_asli) {
 const memanggil_tobrut = await axios.get(
 `https://restapi.cutout.pro/web/ai/generateImage/getGenerateImageTaskResult?batchId=${batchId}`,
 {
 headers: {
 "Accept": "application/json, text/plain, */*",
 "User-Agent": randomUserAgent,
 "X-Forwarded-For": randomIP,
 "Referer": "https://www.cutout.pro/zh-CN/ai-art-generation/upload"
 }
 }
 );
 const gambar_Anu = memanggil_tobrut.data.data.text2ImageVoList;

 kentod_asli = gambar_Anu.every(image => image.status === 1);

 if (kentod_asli) {
 const nganu_model_hasil = gambar_Anu.map((image, index) => ({
 model: model,
 url: image.resultUrl,
 creator_scrape: "INS"
 }));

 nganu_hasil = nganu_hasil.concat(nganu_model_hasil);
 } else {
 await new Promise(resolve => setTimeout(resolve, 1000));
 }
 }
 return nganu_hasil;
 } catch (error) {
 throw error;
 }
 }

 (async () => {
 try {
 const input = args.join(' ').split('|').map(arg => arg.trim());
 const prompt = input[0];
 const model = input[1];
 if (!prompt || !model) {
 m.reply('Silakan berikan prompt dan model yang valid. Contoh: generateimg girl | LoL');
 return;
 }

 const models = [
 "Glowing Forest",
 "Vector Art",
 "Princess",
 "LoL",
 "Realistic Anime",
 "West Coast",
 "Blue Rhapsody",
 "Graffiti",
 "Clown",
 "Elf"
 ];
 if (!models.includes(model)) {
 m.reply(`Model tidak valid. Pilih salah satu dari model berikut: ${models.join(', ')}`);
 return;
 }

 const results = await generateImages(prompt, model);
 for (const result of results) {
 for (const [key, value] of Object.entries(result)) {
 if (key.startsWith('url')) {
 await sky.sendMessage(m.chat, { image: { url: value }, caption: `Gambar dari model ${result.model}` });
 }
 }
 }
 } catch (error) {
 m.reply(`Terjadi kesalahan: ${error.message}`);
 }
 })();
 }
 break
     

case 'delacces': {
if (!isCreator) throw mess.owner
if (!args[0]) return m.reply(`Use ${prefix+command} nomor\nExample ${prefix+command} 628`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = prem.indexOf(ya)
prem.splice(unp, 1)
fs.writeFileSync('./database/premium.json', JSON.stringify(prem))
m.reply(`succes delete ${ya} acces to bot!`)
}
break
case 'tourl4': {
 const axios = require('axios');
 const FormData = require('form-data');
 const fs = require('fs');
 m.reply(mess.wait); // Mengirim pesan 'wait' sementara proses berlangsung

 // Fungsi untuk mengunggah file ke Catbox
 async function uploadToCatbox(filePath) {
 try {
 if (!fs.existsSync(filePath)) {
 throw new Error("File not found");
 }

 const form = new FormData();
 form.append('reqtype', 'fileupload');
 form.append('fileToUpload', fs.createReadStream(filePath));

 const response = await axios.post('https://catbox.moe/user/api.php', form, {
 headers: {
 ...form.getHeaders()
 }
 });

 if (response.status === 200 && response.data) {
 return response.data.trim(); // Mengembalikan URL file yang diunggah
 } else {
 throw new Error(`Upload failed with status: ${response.status}`);
 }
 } catch (err) {
 throw new Error(`Upload failed: ${err.message}`);
 }
 }

 try {
 // Mengunduh dan menyimpan media dari pesan
 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 // Mengecek apakah tipe media adalah gambar
 if (/image/.test(mime) || /video/.test(mime) || /audio/.test(mime)) {
 let url = await uploadToCatbox(media);
 m.reply(`${url}`);
 } else {
 m.reply(`Maaf, hanya gambar, video, atau audio yang dapat diunggah.`);
 }

 // Menghapus file setelah diunggah
 await fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Error: ${err.message}`);
 }
}
break
case 'tourl5': {
 const axios = require('axios');
 const FormData = require('form-data');
 const fs = require('fs');
 const mime = require('mime-types'); // Importing mime-types library

 m.reply(mess.wait); // Mengirim pesan 'wait' sementara proses berlangsung

 // Fungsi untuk mengunggah file ke pomf2.lain.la
 async function uploadToPomf2(filePath) {
 try {
 if (!fs.existsSync(filePath)) {
 throw new Error("File not found");
 }

 const form = new FormData();
 form.append('files[]', fs.createReadStream(filePath));

 const response = await axios.post('https://pomf2.lain.la/upload.php', form, {
 headers: {
 ...form.getHeaders()
 }
 });

 if (response.status === 200 && response.data) {
 return response.data.files[0].url; // Mengembalikan URL file yang diunggah
 } else {
 throw new Error(`Upload failed with status: ${response.status}`);
 }
 } catch (err) {
 throw new Error(`Upload failed: ${err.message}`);
 }
 }

 try {
 // Mengunduh dan menyimpan media dari pesan
 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 // Mengecek jenis media menggunakan mime-types
 let mimeType = mime.lookup(media);
 if (mimeType && (mimeType.startsWith('image') || mimeType.startsWith('video') || mimeType.startsWith('audio'))) {
 let url = await uploadToPomf2(media);
 m.reply(`${url}`);
 } else {
 m.reply(`Maaf, hanya gambar, video, atau audio yang dapat diunggah.`);
 }

 // Menghapus file setelah diunggah
 await fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Error: ${err.message}`);
 }
}
break
case 'tourl6': {
 const axios = require('axios');
 const FormData = require('form-data');
 const fs = require('fs');

 m.reply(mess.wait); // Mengirim pesan 'wait' sementara proses berlangsung

 // Fungsi untuk mengunggah file ke layanan web Uguu
 async function uploadToUguu(filePath) {
 try {
 if (!fs.existsSync(filePath)) {
 throw new Error("File not found");
 }

 const formData = new FormData();
 formData.append('files[]', fs.createReadStream(filePath));

 const response = await axios.post('https://uguu.se/upload', formData, {
 headers: {
 ...formData.getHeaders(),
 },
 params: {
 output: 'json', // Meminta respons dalam format JSON
 },
 });

 if (response.status === 200 && response.data && response.data.files && response.data.files[0]) {
 return response.data.files[0].url; // Mengembalikan URL file yang diunggah
 } else {
 throw new Error(`Upload failed with status: ${response.status}`);
 }
 } catch (err) {
 throw new Error(`Upload failed: ${err.message}`);
 }
 }

 try {
 // Mengunduh dan menyimpan media dari pesan
 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 // Mengecek apakah tipe media adalah gambar, video, atau audio
 if (/image/.test(mime) || /video/.test(mime) || /audio/.test(mime)) {
 let url = await uploadToUguu(media);
 m.reply(`${url}`);
 } else {
 m.reply(`Maaf, hanya gambar, video, atau audio yang dapat diunggah.`);
 }

 // Menghapus file setelah diunggah
 fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Error: ${err.message}`);
 }
}
break
case 'tourl7': {
 const fetch = require('node-fetch');
 const FormData = require('form-data');
 const fs = require('fs');
 const path = require('path');
 const fileType = require('file-type'); // Import modul file-type

 m.reply(mess.wait); // Mengirim pesan 'wait' sementara proses berlangsung

 // Fungsi untuk mengunggah file ke layanan web Videy.co
 async function uploadToVidey(filePath) {
 try {
 if (!fs.existsSync(filePath)) {
 throw new Error("File not found");
 }

 // Baca file dan dapatkan tipe MIME menggunakan file-type
 const buffer = fs.readFileSync(filePath);
 const fileInfo = await fileType.fromBuffer(buffer);
 if (!fileInfo) {
 throw new Error("Cannot detect file type");
 }

 const formData = new FormData();
 formData.append('file', buffer, {
 filename: path.basename(filePath),
 contentType: fileInfo.mime,
 });

 const response = await fetch('https://videy.co/api/upload', {
 method: 'POST',
 body: formData,
 });

 if (!response.ok) {
 throw new Error(`Upload failed with status: ${response.status}`);
 }

 const videoData = await response.json();
 if (!videoData || !videoData.id) {
 throw new Error('Failed to get video ID from response');
 }

 return `https://cdn.videy.co/${videoData.id}.mp4`;
 } catch (err) {
 throw new Error(`Upload failed: ${err.message}`);
 }
 }

 try {
 // Mengunduh dan menyimpan media dari pesan
 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 // Mengecek apakah tipe media adalah gambar, video, atau audio
 const fileInfo = await fileType.fromFile(media);
 if (fileInfo && (fileInfo.mime.startsWith('image') || fileInfo.mime.startsWith('video') || fileInfo.mime.startsWith('audio'))) {
 let url = await uploadToVidey(media);
 m.reply(`${url}`);
 } else {
 m.reply(`Maaf, hanya gambar, video, atau audio yang dapat diunggah.`);
 }

 // Menghapus file setelah diunggah
 fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Error: ${err.message}`);
 }
}
break
case 'bingimg': {
 let text; // Change from const to let for reassignment
 if (args.length >= 1) {
 text = args.slice(0).join(" ");
 } else if (m.quoted && m.quoted.text) {
 text = m.quoted.text;
 } else {
 return m.m.reply("*Example:* .bingimg 1girl");
 }

 const { BingImageCreator } = require("./lib/bingimg");
 await m.reply("Please wait...");

 try {
 const res = new BingImageCreator({
 cookie: `1OQJWqw84X2IsJ3v0doRxiXup7hGX7xSlWeoaHJfO92u9XBoK2a7GPThQLfnZorFhudCLEJmYzXn6eCsESGejupcnSnfx1BAypz46osaE8OXxdZS4eqQ5FzFt3nXQnL-gmi5MTBf4iQ8te7zSpb3KgwR3BNXM5MU_WgZPNNuTA_pPjaD-CVmpavXtjGChn6w_74gathJf5NZnFQPsarSvug; WLID=mjnAuahThR9MgaUmfnMfZ/fy5VZvHX82hacSw2tYC5OocGKi8oYH7xcaLX2J1xEqLy5LpSiPGMyuSwGTbQi7XyzeqmcL+hDZO66FrMumONA=; _EDGE_S=SID=28563962BAEB61533DFA2DFDBBBD606D` // Ensure this is managed securely
 });

 const data = await res.createImage(text);

 if (data.length > 0) {
 for (let i = 0; i < data.length; i++) {
 try {
 if (!data[i].endsWith(".svg")) {
 await sky.sendFile(
 m.chat,
 data[i],
 "",
 `Image *(${i + 1}/${data.length})*\n\n*Prompt*: ${text}`,
 m,
 false,
 { mentions: [m.sender] }
 );
 }
 } catch (error) {
 console.error(`Error sending file: ${error.message}`);
 await m.reply(`Failed to send image *(${i + 1}/${data.length})*`);
 }
 }
 } else {
 await m.reply("No images found.");
 }
 } catch (error) {
 console.error(`Error in handler: ${error.message}`);
 await m.reply(`${error}\n\n${error.message}`);
 }
};
break
case 'instagram': case 'ig': case 'igvideo': case 'igimage': case 'igvid': case 'igdl': {
	 if (!text) return m.reply(`You need to give the URL of Any Instagram video, post, reel, image`)
 let res
 try {
 res = await fetch(`https://www.guruapi.tech/api/igdlv1?url=${text}`)
 } catch (error) {
 return m.reply(`An error occurred: ${error.message}`)
 }
 let api_response = await res.json()
 if (!api_response || !api_response.data) {
 return m.reply(`No video or image found or Invalid response from API.`)
 }
 const mediaArray = api_response.data;
 for (const mediaData of mediaArray) {
 const mediaType = mediaData.type
 const mediaURL = mediaData.url_download
 let cap = `ni ${mediaType.toUpperCase()}`
 if (mediaType === 'video') {
 sky.sendMessage(m.chat, {video: {url: mediaURL}, caption: cap}, {quoted: m})
 } else if (mediaType === 'image') {
 sky.sendMessage(m.chat, { image: {url: mediaURL}, caption: cap}, {quoted: m})
 }
 }
}
break
case 'fbdl': {
 if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
 if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit);

 db.data.users[m.sender].limit -= 10; // Kurangi limit

 if (!text) return m.reply('Masukkan Query Link!');
 m.reply(mess.wait);

 try {
 const response = await axios.get(`https://widipe.com/download/fbdl?url=${encodeURIComponent(q)}`);
 const { result } = response.data;

 if (!result || !result.HD) return m.reply('Video tidak ditemukan atau mungkin private.');

 sky.sendMessage(m.chat, { video: { url: result.HD }, mimetype: 'video/mp4' });
 } catch (error) {
 console.error(error);
 m.reply('Terjadi kesalahan saat mengambil video.');
 }
}
break
case 'ringtone': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!text) throw `Example : ${prefix + command} black rover`
 let { ringtone } = require('./lib/scraper')
		let anu = await ringtone(text)
		let result = anu[Math.floor(Math.random() * anu.length)]
		sky.sendMessage(m.chat, { audio: { url: result.audio }, fileName: result.title+'.mp3', mimetype: 'audio/mpeg' }, { quoted: m })
	 }
	 break
case "luminai":{
 if (!text) return m.kirim("halo?");
 try {
 if (quoted && /image/.test(quoted.mimetype)) {
 let anu = (await axios.post("https://luminai.siputzx.my.id/", { content: text, imageBuffer: await quoted.download(), user: sender })).data.result;
 m.reply(anu);
 } else {
 let anu = (await axios.post("https://luminai.siputzx.my.id/", { content: text, user: sender })).data.result;
 m.reply(anu);
 }
 } catch (e) {
 m.kirim(e);
 }}
 break
case "luminai": {
 if (!text) return m.kirim("halo?");
 try {
 if (quoted && /image/.test(quoted.mimetype)) {
 let anu = (await axios.post("https://luminai.siputzx.my.id/", { content: text, imageBuffer: await quoted.download(), user: `namaku adalah avosky aku tingal di gunung` })).data.result;
 m.reply(anu);
 } else {
 let anu = (await axios.post("https://luminai.siputzx.my.id/", { content: text, user: `namaku adalah avosky aku tingal di gunung` })).data.result;
 m.reply(anu);
 }
 } catch (e) {
 m.kirim(e);
 }}
 break
case 'cekjoin': {
 if (!m.isGroup) return m.reply('Hanya bisa digunakan di grup.');
 if (!isBotAdmins) return m.reply('Bot harus menjadi admin untuk melakukan ini.');
 
 const response = await sky.groupRequestParticipantsList(m.chat);
 if (!response || !response.length) {
 sky.sendMessage(m.chat, { text: 'Tidak ada permintaan bergabung tertunda. ✅' }, { quoted: m });
 return;
 }
 
 let replyMessage = `Daftar Permintaan Bergabung:\n`;
 response.forEach((request, index) => {
 const { jid, request_method, request_time } = request;
 
 // Mengambil hanya bagian nomor dari JID
 const jidNumber = jid.split('@')[0]; // Ambil bagian sebelum '@'
 
 const formattedTime = new Date(parseInt(request_time) * 1000).toLocaleString();
 replyMessage += `\n*No.: ${index + 1} Detail Permintaan. 👇*`;
 replyMessage += `\n*Nomor:* ${jidNumber}`;
 replyMessage += `\n*Metode:* ${request_method}`;
 replyMessage += `\n*Waktu:* ${formattedTime}\n`;
 });
 
 sky.sendMessage(m.chat, { text: replyMessage }, { quoted: m });
};
break
case 'acc': {
 const groupId = m.chat;
 const [subCommand, options] = args;
 const joinRequestList = await sky.groupRequestParticipantsList(groupId);

 const formatDate = (timestamp) => new Intl.DateTimeFormat('id-ID', {
 weekday: 'long',
 day: 'numeric',
 month: 'long',
 year: 'numeric'
 }).format(new Date(timestamp * 1000));


 switch (subCommand) {
 case 'list':
 const formattedList = joinRequestList.length > 0 ?
 joinRequestList.map((request, i) => `*${i + 1}.*\n• Nomor: ${request.jid.split('@')[0]}\n• Metode Permintaan: ${request.request_method}\n• Waktu Permintaan: ${formatDate(request.request_time)}\n\n`).join('') :
 "Tidak ada permintaan bergabung yang tertunda.";
 m.reply(`*Daftar Permintaan Bergabung:*\n\n${formattedList}`);
 break;

 case 'reject':
 case 'approve':
 if (options === "all") {
 for (const request of joinRequestList) {
 await sky.groupRequestParticipantsUpdate(groupId, [request.jid], subCommand);
 console.log(`Meng-${subCommand} participant dengan JID: ${request.jid}`);
 }
 m.reply(`*${subCommand === 'approve' ? 'Menyetujui' : 'Menolak'} semua permintaan bergabung.*`);
 } else {
 const actions = options.split('|').map(action => action.trim());
 const participants = actions.map(action => joinRequestList[parseInt(action) - 1]).filter(request => request);
 if (participants.length > 0) {
 let formattedResponse = '';
 for (const request of participants) {
 const response = await sky.groupRequestParticipantsUpdate(groupId, [request.jid], subCommand);
 const status = response[0].status === 'success' ? 'Gagal' : 'Berhasil';
 formattedResponse += `*${participants.indexOf(request) + 1}.*\n• Status: ${status}\n• Nomor: ${request.jid.split('@')[0]}\n\n`;
 console.log(`Meng-${subCommand} participant dengan JID: ${request.jid}`);
 }
 m.reply(`*${subCommand === 'approve' ? 'Menyetujui' : 'Menolak'} Permintaan Bergabung:*\n\n${formattedResponse}`);
 } else {
 m.reply("Tidak ada anggota yang cocok untuk reject/approve.");
 }
 }
 break;

 default:
 m.reply("*Perintah tidak valid.*\nGunakan:\n- *acc list*\n- *acc approve [number]*\n- *acc reject [number]*\n- *acc reject [JID]*\n- *acc reject/approve all* untuk menolak/menyetujui semua permintaan bergabung.");
 }
 }
 break
case 'emojimix2': {
 if (!text) return m.reply(`Example : ${prefix + command} 😅`)
 let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(text)}`)
 for (let res of anu.results) {
 let encmedia = await sky.sendImageAsSticker(m.chat, res.url, m, {
 packname: global.packname,
 author: global.author,
 categories: res.tags
 })
 }
 }
 break
case 'cek': {
 if (!m.isGroup) throw mess.group;

 // Deteksi anggota berdasarkan awalan nomor
 const foreignMembersList = [];
 let indonesiaMembers = 0;

 for (const member of participants) {
 const countryCode = member.id.replace(/[^0-9]/g, '').substring(0, 2);
 if (countryCode !== '62' && countryCode !== '60') {
 foreignMembersList.push(`- ${member.id.split('@')[0]}`);
 } else if (countryCode === '62') {
 indonesiaMembers++;
 }
 }

 // Menampilkan list anggota luar
 if (foreignMembersList.length > 0) {
 const totalMembers = participants.length;
 const totalForeignMembers = foreignMembersList.length;
 const totalIndonesiaMembers = indonesiaMembers;

 const responseText = `🌍 *List Anggota Luar Grup*:\n${foreignMembersList.join('\n')}\n\n👤 *Total Anggota*: ${totalMembers}\n🇮🇩 *Indonesia*: ${totalIndonesiaMembers} anggota\n🌐 *Luar Indonesia*: ${totalForeignMembers} anggota`;
 
 m.reply(responseText);
 } else {
 m.reply('Tidak ada anggota luar di grup ini.');
 }
}
 break
case 'getcase2':
if (!isCreator) throw mess.owner
if (!text) throw 'input case'
const getCase = (cases) => {
return "case"+`'${cases}'`+fs.readFileSync("sky2.js").toString().split('case \''+cases+'\'')[1].split("break")[0]+"break"
}
m.reply(`${getCase(q)}`)
break
case 'smeme': case 'smim': {
 const uploadImage = require('./lib/uploadImage')
 let media = await sky.downloadAndSaveMediaMessage(qmsg);
 let buffer = fs.readFileSync(media);
 let url = await uploadImage(buffer);
kaytid = await getBuffer(`https://api.memegen.link/images/custom/-/${text}.png?background=${url}`)
sky.sendImageAsSticker(m.chat, kaytid, m, { packname: global.packname, author: global.author }) 
 }
break
case 'memgen': {
 if (!isCreator) return m.reply(mess.owner);

 const input = args.join(' ').trim().split('|').map(item => item.trim());
 
 if (input.length !== 3) {
 m.reply('Format yang kamu masukkan salah. Gunakan format: memgen template | text1 | text2\n\nList template yang tersedia:\n1. buzz\n2. y-u-no\n3. grumpycat\n4. wonka\n5. disastergirl\n6. philosoraptor\n7. drevil\n8. interesting\n9. facepalm\n10. afraid\n11. picard\n12. patrick\n13. fry\n14. captain\n15. simply\n16. onedoes\n17. sohappy\n18. noidea\n19. toohigh\n20. angry\n21. spongebob\n22. archer\n23. bender\n24. dwight\n25. morpheus\n26. joker\n27. jw\n28. ll\n29. badchoice\n30. baby\n31. wonka\n32. facepalm\n33. blb\n34. disastergirl\n35. matrix\n36. philosoraptor\n37. rollsafe\n38. success\n39. drevil\n40. afraid\n41. older\n42. patrick\n43. boat\n44. car\n45. disastergirl\n46. matrix\n47. philosoraptor\n48. rollsafe\n49. success\n50. drevil');
 return;
 }

 const template = input[0];
 const topText = encodeURIComponent(input[1]);
 const bottomText = encodeURIComponent(input[2]);

 const memeUrl = `https://api.memegen.link/images/${template}/${topText}/${bottomText}.png`;

 fetch(memeUrl)
 .then(response => response.buffer())
 .then(buffer => {
 const memePath = path.join(__dirname, 'meme.png');
 const stickerPath = path.join(__dirname, 'sticker.webp');
 fs.writeFile(memePath, buffer, (err) => {
 if (err) {
 m.reply('Gagal membuat meme.');
 console.error(err);
 } else {
 exec(`ffmpeg -i ${memePath} -vf "scale=512:512:force_original_aspect_ratio=decrease" -vcodec webp -lossless 1 -qscale 100 -preset default -an -vsync 0 ${stickerPath}`, (err) => {
 if (err) {
 m.reply('Gagal mengonversi meme menjadi stiker.');
 console.error(err);
 } else {
 sky.sendFile(m.chat, stickerPath, 'sticker.webp', 'Ini stikermu!', m);
 fs.unlinkSync(memePath);
 fs.unlinkSync(stickerPath);
 }
 });
 }
 });
 })
 .catch(err => {
 m.reply('Terjadi kesalahan saat membuat meme.');
 console.error(err);
 });
 }
 break
case 'save': {
 if (!isPrem) return replyprem(mess.premium);
 if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');

 let contacts = [];
 let name = text ? text.split(' ')[1] : sky.getName(m.sender); // Mengambil nama dari input, jika ada
 let numberOfContacts = parseInt(text.split(' ')[0]); // Mengambil jumlah kontak yang akan disimpan dari input

 // Validasi jumlah kontak yang akan disimpan
 if (isNaN(numberOfContacts) || numberOfContacts <= 0) {
 m.reply('Tentukan jumlah kontak yang valid untuk disimpan.');
 return;
 }

 // Mengumpulkan sejumlah anggota grup
 for (let i = 0; i < numberOfContacts && i < participants.length; i++) {
 let member = participants[i];
 let number = member.id.split('@')[0];
 let vcard = `
BEGIN:VCARD
VERSION:3.0
FN:@${number}
TEL;type=CELL;type=VOICE;waid=${number}:${m.sender.split('@')[0]}
END:VCARD`;
 contacts.push({ vcard });
 }

 // Mengirim semua kontak dalam satu pesan
 sky.sendMessage(m.chat, { contacts: { displayName: name, contacts } }, { quoted: fkontak });
}
break
case 'freelimit': {
let { proto, generateWAMessageFromContent } = require('@whiskeysockets/baileys')

let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `be fast`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: `klik di sini untuk mendapatkan limit acak 1-5000`
 }), 
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\".............................................................................................iyaiya aku emang anak haram maaf ya aku ngaku aku anak haram.........\",\"id\":\".haram\"}`
 }, 
 ],
 })
 })
 }
 }
}, {})

sky.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
}
break

case 'bible': {
const translate = require('translate-google'); // Import translate-google library
 if (!text) throw 'john 3:3'; // Default verse if no specific query provided
 const apiUrl = `https://bible-api.com/${encodeURIComponent(text)}`;

 axios.get(apiUrl)
 .then(response => {
 const bibleVerse = response.data;
 const verseTextEN = bibleVerse.text.trim(); // English verse text

 // Translate to Indonesian
 translate(verseTextEN, { to: 'id' })
 .then(translatedText => {
 const message = `🔃 Sumber: https://www.bible.com\n📖 Ayat Alkitab (${text}):\n\nEN:\n${verseTextEN}\n\nID:\n${translatedText}`;
 m.reply(message);
 })
 .catch(err => {
 console.error('Error translating verse to Indonesian:', err);
 m.reply('Maaf, terjadi kesalahan saat menerjemahkan teks.');
 });
 })
 .catch(error => {
 console.error('Error fetching Bible verse:', error);
 m.reply('Maaf, terjadi kesalahan dalam mengambil ayat Alkitab.');
 });
}
break
case 'gpt4': {

 if (!text) throw `Hello ${pushname}, may I help you?`;

 const { key } = await sky.sendMessage(from, { text: '_Please Wait..._', previewType: 0 });

 try {
 const { data } = await axios.get(`https://itzpire.com/ai/gpt?model=gpt-4&q=${encodeURIComponent(text)}`);
 await sky.sendMessage(from, { text: `${data.data.response}`.trim(), edit: key });
 } catch (error) {
 await sky.sendMessage(from, { text: 'An error occurred while processing your request.', edit: key });
 }
}
break
case 'obfuscate': {
 if (!args[0]) {
 m.reply('Harap masukkan teks yang ingin diobfuscate.');
 return;
 }

 const inputText = args.join(' ');

 function obfuscate(text) {
 let obfuscated = '';
 for (let i = 0; i < text.length; i++) {
 obfuscated += '\\u' + ('000' + text.charCodeAt(i).toString(16)).slice(-4);
 }
 return obfuscated;
 }

 const obfuscatedText = obfuscate(inputText);

 m.reply(`Teks yang diobfuscate:\n${obfuscatedText}`);
}
 break
case 'deobfuscate': {
 if (!args[0]) {
 m.reply('Harap masukkan teks yang ingin dideobfuscate.');
 return;
 }

 const inputText = args.join(' ');

 function deobfuscate(text) {
 return text.replace(/\\u([\dA-Fa-f]{4})/g, function (match, grp) {
 return String.fromCharCode(parseInt(grp, 16));
 });
 }

 const deobfuscatedText = deobfuscate(inputText);

 m.reply(`Teks yang dideobfuscate:\n${deobfuscatedText}`);
}
 break
case 'obfuscate2': {
const JavaScriptObfuscator = require('javascript-obfuscator');

 if (!isCreator) return m.reply(mess.owner);

 // Mengambil kode yang akan diobfuscate dari argumen
 const code = args.join(' ');
 if (!code) {
 m.reply('Tolong berikan kode yang ingin diobfuscate.');
 return;
 }

 // Mengobfuscate kode menggunakan JavaScript Obfuscator
 const obfuscatedCode = JavaScriptObfuscator.obfuscate(
 code,
 {
 compact: true,
 controlFlowFlattening: true,
 }
 ).getObfuscatedCode();

 // Mengirimkan kode yang telah diobfuscate kepada pengguna
 m.reply(`Kode yang telah diobfuscate:\n\n${obfuscatedCode}`);
}
break
case 'deobfuscate2': {
 if (!args[0]) {
 m.reply('Harap masukkan teks yang ingin dideobfuscate.');
 return;
 }

 const inputText = args.join(' ');

 try {
 const deobfuscate = (text) => {
 try {
 const decoded = eval(text); // Berbahaya, hanya untuk contoh
 return decoded;
 } catch (error) {
 throw new Error('Tidak dapat mendekode teks yang diberikan.');
 }
 }

 const deobfuscatedText = deobfuscate(inputText);
 m.reply(`Teks yang dideobfuscate:\n${deobfuscatedText}`);
 } catch (error) {
 m.reply(`Terjadi kesalahan saat mendekode teks: ${error.message}`);
 }
}
 break
case 'ytaudio': case 'tinyurl': {
 const targetUrl = args.join(' ');
 if (!targetUrl) {
 return m.reply('Silakan masukkan URL yang ingin diperpendek.');
 }

 const shortenUrl = async (url) => {
 try {
 const response = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`);
 const shortenedUrl = await response.text();
 return shortenedUrl;
 } catch (error) {
 console.error(error);
 return null;
 }
 };

 shortenUrl(targetUrl).then((shortenedUrl) => {
 if (shortenedUrl) {
 m.reply(`Berhasil memperpendek URL: ${shortenedUrl}`);
 } else {
 m.reply('Terjadi kesalahan saat memperpendek URL.');
 }
 });
}
 break
 case 'gsmarena': {
  if (args.length === 0) {
    m.reply('⚠️ Silakan masukkan nama perangkat yang ingin dicari.');
    return;
  }

  async function gsmSearch(q) {
    try {
      const response = await axios({
        method: "get",
        url: `https://gsmarena.com/results.php3?sQuickSearch=yes&sName=${q}`
      });
      const $ = cheerio.load(response.data);
      const result = [];
      
      const device = $(".makers").find("li");
      device.each((i, e) => {
        const img = $(e).find("img");
        result.push({
          id: $(e).find("a").attr("href").replace(".php", ""),
          name: $(e).find("span").html().split("<br>").join(" "),
          description: img.attr("title")
        });
      });
      return result;
    } catch (error) {
      console.error(error);
      throw error;
    }
  }

  gsmSearch(q).then(results => {
    if (results.length === 0) {
      m.reply('❌ Tidak ada hasil yang ditemukan.');
      return;
    }
    
    let replyText = `🔍 Hasil pencarian untuk "${q}":\n\n`;
    results.forEach((device, index) => {
      replyText += ` 📱 ${index + 1}. *${device.name}*\n 📄 Deskripsi: ${device.description}\n🔗 Link : https://gsmarena.com/${device.id}.php`;
    });
    
    m.reply(replyText);
  }).catch(error => {
    m.reply('❌ Terjadi kesalahan saat mencari perangkat.');
    console.error(error);
  });
}
  break

case 'smoke': {
m.reply(mess.wait)
if (!q) return m.reply(`Example : ${prefix + command} Kayla`);
let link;
if (/smoke/.test(command))
link =
 'https://photooxy.com/other-design/create-an-easy-smoke-type-effect-390.html';
 let dehe = await photooxy.photoOxy(link, q);
sky.sendMessage(
m.chat,
{ image: { url: dehe }, caption: `done`},
{ quoted: m }
);
}
break
case 'photooxy': {
 m.reply(mess.wait); // Mengirim pesan menunggu

 const [url, text] = q.split('|'); // Memisahkan URL dan teks input dari pengguna

 if (!url || !text) return m.reply(`Contoh: .photooxy <url>|<teks>`); // Memastikan ada URL dan teks yang diberikan

 const photooxy = async (url, text) => {
 const axios = require('axios');
 const FormData = require('form-data');
 const cheerio = require('cheerio');

 try {
 let form = new FormData();
 let gT = await axios.get(url, {
 headers: {
 'user-agent':
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
 },
 });
 let $ = cheerio.load(gT.data);
 let token = $('input[name=token]').val();
 let build_server = $('input[name=build_server]').val();
 let build_server_id = $('input[name=build_server_id]').val();
 form.append('text[]', text);
 form.append('token', token);
 form.append('build_server', build_server);
 form.append('build_server_id', build_server_id);
 let res = await axios({
 url: url,
 method: 'POST',
 data: form,
 headers: {
 Accept: '*/*',
 'Accept-Language': 'en-US,en;q=0.9',
 'user-agent':
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
 cookie: gT.headers['set-cookie']?.join('; '),
 ...form.getHeaders(),
 },
 });

 // Check if response data is empty or not valid
 if (!res.data) {
 throw new Error('Empty response or invalid JSON data');
 }

 // Parse JSON data
 let $$ = cheerio.load(res.data);
 let json = JSON.parse($$('input[name=form_value_input]').val());

 // Handle empty JSON or unexpected format
 if (!json || typeof json !== 'object') {
 throw new Error('Invalid JSON data received');
 }

 json['text[]'] = json.text;
 delete json.text;
 let { data } = await axios.post(
 'https://www.photooxy.com/effect/create-image',
 new URLSearchParams(json),
 {
 headers: {
 'user-agent':
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
 cookie: gT.headers['set-cookie'].join('; '),
 },
 }
 );
 return build_server + data.image;
 } catch (error) {
 console.error(error);
 throw new Error('Error generating image!');
 }
 };

 try {
 let imageUrl = await photooxy(url.trim(), text.trim()); // Menghasilkan gambar dengan teks yang diberikan
 sky.sendMessage(
 m.chat,
 { image: { url: imageUrl }, caption: 'Selesai' }, // Mengirimkan gambar hasil ke pengguna
 { quoted: m }
 );
 } catch (e) {
 m.reply("Error menghasilkan gambar!"); // Menangani kesalahan dan mengirim pesan error
 console.error(e); // Log error untuk debugging
 }
}
 break
case 'obf': {
const JavaScriptObfuscator = require('javascript-obfuscator');

// Fungsi untuk menghasilkan kode JavaScript yang terenkripsi
function obfuscateCode(code) {
 const obfuscationResult = JavaScriptObfuscator.obfuscate(
 code,
 {
 compact: true,
 controlFlowFlattening: true,
 controlFlowFlatteningThreshold: 0.75,
 numbersToExpressions: true,
 simplify: true,
 shuffleStringArray: true,
 splitStrings: true,
 stringArrayThreshold: 1
 }
 );
 return obfuscationResult.getObfuscatedCode();
}
 const code = args.join(' ');
 if (!code) {
 return m.reply('Silakan masukkan kode JavaScript yang ingin Anda enkripsi.');
 }
 try {
 const obfuscatedCode = obfuscateCode(code);
 m.reply(`${obfuscatedCode}`);
 } catch (error) {
 m.reply('Terjadi kesalahan dalam melakukan enkripsi kode JavaScript.');
 }
 }
 break
case 'deobf': {
 const JavaScriptObfuscator = require('javascript-obfuscator');

 // Fungsi untuk mengembalikan kode JavaScript yang telah dienkripsi
 function deobfuscateCode(obfuscatedCode) {
 try {
 const deobfuscationResult = JavaScriptObfuscator.obfuscate(obfuscatedCode, { 
 // opsi disini
 });
 return deobfuscationResult.getObfuscatedCode(); // Mengembalikan kode yang dideobfuscate
 } catch (error) {
 return `Gagal mengembalikan kode dari obfuscation. Pesan kesalahan: ${error.message}`;
 }
 }

 const obfuscatedCode = args.join(' ');
 if (!obfuscatedCode) {
 return m.reply('Silakan masukkan kode JavaScript yang telah dienkripsi.');
 }

 try {
 const deobfuscatedCode = deobfuscateCode(obfuscatedCode);
 m.reply(`${deobfuscatedCode}`);
 } catch (error) {
 m.reply(`Terjadi kesalahan dalam melakukan deobfuscation kode JavaScript: ${error.message}`);
 }
}
break

case 'ttaudio': case 'tiktokaudio': {
try {
if (!text) return m.reply(`Example : ${prefix + command} link`)
m.reply(mess.wait)
axios.get(`https://widipe.com/download/ttdl?url=${q}`).then(({ data }) => {
				sky.sendMessage(from, { audio: { url: data.result.audio[0] }, mimetype: "audio/mp4", fileName: "Audio" }, { quoted: m })
			})			
} catch (err) {
console.log(err)
m.reply('Terjadi Kesalahan')
}
}
break
 case 'backup': {
let jir = m.mentionedJid[0] || m.sender || sky.parseMention(args[0]) || (args[0].replace(/[@.+-]/g, '').replace(' ', '') + '@s.whatsapp.net') || '';
await m.reply('load');
const { execSync } = require("child_process");
 const ls = (await execSync("ls")).toString().split("\n").filter( (pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != "" );
await m.reply('sc akan dibackup')
const exec = await execSync(`zip -r Backup.zip ${ls.join(" ")}`);
await sky.sendMessage(jir, {
document: await fs.readFileSync("./Backup.zip"),
mimetype: "application/zip",
fileName: "Backup.zip",
},
{quoted: m });
await execSync("rm -rf Backup.zip");
}
break
case 'delhome': {
 if (!isCreator) return m.reply('Perintah ini hanya bisa digunakan oleh creator');

 let directoryPath = path.join('./'); // Jika ingin memeriksa direktori lain, sesuaikan path-nya

 fs.readdir(directoryPath, async function (err, files) {
 if (err) {
 return m.reply('Tidak dapat memindai direktori: ' + err);
 } 

 let filteredArray = files.filter(item => 
 item.endsWith("gif") || 
 item.endsWith("zip") || 
 item.endsWith("png") || 
 item.endsWith("mp3") || 
 item.endsWith("mp4") || 
 item.endsWith("jpg") || 
 item.endsWith("jpeg") || 
 item.endsWith("webp") || 
 item.endsWith("webm")
 );

 let teks = `Terdeteksi ${filteredArray.length} file sampah di direktori home\n\n`;
 if (filteredArray.length == 0) return m.reply(teks);

 filteredArray.forEach(function(e, i) {
 teks += (i + 1) + `. ${e}\n`;
 });

 m.reply(teks);

 await sleep(2000);
 m.reply("_Proses membersihkan home..._");

 let deletedFiles = [];
 filteredArray.forEach(function (file) {
 fs.unlinkSync(path.join(directoryPath, file)); // Menghapus file dari direktori
 deletedFiles.push(file); // Menambahkan file yang dihapus ke dalam daftar
 });

 await sleep(2000);
 
 let deletedTeks = "Berhasil membersihkan file berikut:\n\n";
 deletedFiles.forEach(function(file, i) {
 deletedTeks += (i + 1) + `. ${file}\n`;
 });

 m.reply(deletedTeks);
 });
}
break
case 'img-gen-reality': {
 if (!isCreator) return m.reply(mess.owner);

 const { G4F } = require("g4f");
 const fs = require("fs");

 const g4f = new G4F();
 const input = args.join(' ').split('|');
 if (input.length < 2) {
 m.reply('Format salah. Gunakan: generateimg <query> | <provider>');
 return;
 }

 const query = input[0].trim();
 const providerName = input[1].trim();

 const providers = {
 Emi: g4f.providers.Emi,
 Dalle: g4f.providers.Dalle,
 DalleMini: g4f.providers.DalleMini,
 Prodia: g4f.providers.Prodia,
 StableDiffusionPlus: g4f.providers.StableDiffusionPlus,
 StableDiffusionLite: g4f.providers.StableDiffusionLite
 };

 const provider = providers[providerName];
 if (!provider) {
 m.reply(`Provider tidak valid. Pilih salah satu dari: ${Object.keys(providers).join(', ')}`);
 return;
 }

 (async () => {
 try {
 const base64Image = await g4f.imageGeneration(query, { 
 debug: true,
 provider: provider,
 providerOptions: {
 model: "ICantBelieveItsNotPhotography_seco.safetensors [4e7a3dfd]",
 samplingSteps: 15,
 cfgScale: 30
 }
 });

 const imagePath = 'image.jpg';
 fs.writeFile(imagePath, base64Image, { encoding: 'base64' }, function(err) {
 if (err) {
 console.error('Error writing the file: ', err);
 m.reply('Terjadi kesalahan saat menyimpan gambar.');
 return;
 }
 console.log('The image has been successfully saved as image.jpg.');
 sky.sendFile(m.chat, imagePath, 'image.jpg', 'Ini adalah gambar yang dihasilkan berdasarkan query Anda.');
 });
 } catch (error) {
 console.error('Error generating image: ', error);
 m.reply('Terjadi kesalahan saat menghasilkan gambar.');
 }
 })();
}
break
case 'img-gen-paint': {
 if (!isCreator) return m.reply(mess.owner);

 const { G4F } = require("g4f");
 const fs = require("fs");

 const g4f = new G4F();
 const input = args.join(' ').split('|');
 if (input.length < 2) {
 m.reply('Format salah. Gunakan: img-gen-paint <query> | <provider>');
 return;
 }

 const query = input[0].trim();
 const providerName = input[1].trim();

 const providers = {
 Emi: g4f.providers.Emi,
 Dalle: g4f.providers.Dalle,
 DalleMini: g4f.providers.DalleMini,
 Prodia: g4f.providers.Prodia,
 StableDiffusionPlus: g4f.providers.StableDiffusionPlus,
 StableDiffusionLite: g4f.providers.StableDiffusionLite,
 Pixart: g4f.providers.Pixart
 };

 const provider = providers[providerName];
 if (!provider) {
 m.reply(`Provider tidak valid. Pilih salah satu dari: ${Object.keys(providers).join(', ')}`);
 return;
 }

 (async () => {
 try {
 const base64Image = await g4f.imageGeneration(query, { 
 debug: true,
 provider: provider,
 providerOptions: {
 height: 512,
 width: 512,
 samplingMethod: "SA-Solver"
 }
 });

 const imagePath = 'image.jpg';
 fs.writeFile(imagePath, base64Image, { encoding: 'base64' }, function(err) {
 if (err) {
 console.error('Error writing the file: ', err);
 m.reply('Terjadi kesalahan saat menyimpan gambar.');
 return;
 }
 console.log('The image has been successfully saved as image.jpg.');
 sky.sendFile(m.chat, imagePath, 'image.jpg', 'Ini adalah gambar yang dihasilkan berdasarkan query Anda.');
 });
 } catch (error) {
 console.error('Error generating image: ', error);
 m.reply('Terjadi kesalahan saat menghasilkan gambar.');
 }
 })();
}
break
case 'img-gen-cartoon': {
 if (!isCreator) return m.reply(mess.owner);

 const { G4F } = require("g4f");
 const fs = require("fs");

 const g4f = new G4F();
 const input = args.join(' ').split('|');
 if (input.length < 2) {
 m.reply('Format salah. Gunakan: img-gen-cartoon <query> | <provider>');
 return;
 }

 const query = input[0].trim();
 const providerName = input[1].trim();

 const providers = {
 Emi: g4f.providers.Emi,
 Dalle: g4f.providers.Dalle,
 DalleMini: g4f.providers.DalleMini,
 Prodia: g4f.providers.Prodia,
 StableDiffusionPlus: g4f.providers.StableDiffusionPlus,
 StableDiffusionLite: g4f.providers.StableDiffusionLite,
 Pixart: g4f.providers.Pixart
 };

 const provider = providers[providerName];
 if (!provider) {
 m.reply(`Provider tidak valid. Pilih salah satu dari: ${Object.keys(providers).join(', ')}`);
 return;
 }

 (async () => {
 try {
 const base64Image = await g4f.imageGeneration(query, { 
 debug: true,
 provider: provider
 });

 const imagePath = 'image.jpg';
 fs.writeFile(imagePath, base64Image, { encoding: 'base64' }, function(err) {
 if (err) {
 console.error('Error writing the file: ', err);
 m.reply('Terjadi kesalahan saat menyimpan gambar.');
 return;
 }
 console.log('The image has been successfully saved as image.jpg.');
 sky.sendFile(m.chat, imagePath, 'image.jpg', 'Ini adalah gambar yang dihasilkan berdasarkan query Anda.');
 });
 } catch (error) {
 console.error('Error generating image: ', error);
 m.reply('Terjadi kesalahan saat menghasilkan gambar.');
 }
 })();
}
break
case 'infocuaca': {
 const weather = require('weather-js');
 if (!isCreator) return m.reply(mess.owner);

 // Ambil nama kota dari args
 const cityName = args.join(' ');

 // Validasi nama kota
 if (!cityName) {
 m.reply('🌍 Tentukan nama kota untuk mendapatkan informasi cuaca.');
 return;
 }

 // Mengambil data cuaca dari weather-js
 weather.find({ search: cityName, degreeType: 'C' }, function(err, result) {
 if (err) {
 m.reply('❌ Terjadi kesalahan saat mengambil data cuaca.');
 console.error(err);
 return;
 }

 if (!result || result.length === 0) {
 m.reply('❌ Gagal mendapatkan data cuaca. Pastikan nama kota benar.');
 return;
 }

 // Ambil detail cuaca dari result
 const location = result[0].location.name || 'N/A';
 const current = result[0].current;
 const forecast = result[0].forecast[1]; // Ambil prediksi cuaca untuk hari berikutnya

 // Tentukan emotikon berdasarkan kondisi cuaca
 const weatherIcons = {
 'Sunny': '☀️',
 'Clear': '🌕',
 'Partly Cloudy': '⛅',
 'Cloudy': '☁️',
 'Rain': '🌧️',
 'Thunderstorm': '⛈️',
 'Snow': '❄️',
 'Fog': '🌫️'
 };
 const currentIcon = weatherIcons[current.skytext] || '🌈';
 const forecastIcon = weatherIcons[forecast.skytextday] || '🌈';

 // Buat pesan detail cuaca
 const weatherDetail = `🌆 Cuaca di *${location}*:\n\n` +
 `${currentIcon} *Deskripsi:* ${current.skytext || 'N/A'}\n` +
 `🌡️ *Suhu:* ${current.temperature || 'N/A'}°C\n` +
 `🌡️ *Terasa Seperti:* ${current.feelslike || 'N/A'}°C\n` +
 `💧 *Kelembapan:* ${current.humidity || 'N/A'}%\n` +
 `🌬️ *Kecepatan Angin:* ${current.winddisplay || 'N/A'}\n` +
 `🌡️ *Suhu Maksimum:* ${forecast.high || 'N/A'}°C\n` +
 `🌡️ *Suhu Minimum:* ${forecast.low || 'N/A'}°C`;

 // Kirim pesan detail cuaca
 m.reply(weatherDetail);
 });
}
break
case 'ttslide': {
async function tiktok(url) {
 const data = new URLSearchParams({
 'id': url,
 'locale': 'id',
 'tt': 'RFBiZ3Bi'
 });

 const headers = {
 'HX-Request': true,
 'HX-Trigger': '_gcaptcha_pt',
 'HX-Target': 'target',
 'HX-Current-URL': 'https://ssstik.io/id',
 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
 'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
 'Referer': 'https://ssstik.io/id'
 };

 const response = await axios.post('https://ssstik.io/abc?url=dl', data, {
 headers
 });
 const html = response.data;

 const $ = cheerio.load(html);

 const author = $('#avatarAndTextUsual h2').text().trim();
 const title = $('#avatarAndTextUsual p').text().trim();
 const video = $('.result_overlay_buttons a.download_link').attr('href');
 const audio = $('.result_overlay_buttons a.download_link.music').attr('href');
 const imgLinks = [];
 $('img[data-splide-lazy]').each((index, element) => {
 const imgLink = $(element).attr('data-splide-lazy');
 imgLinks.push(imgLink);
 });

 const result = {
 author,
 title,
 result: video || imgLinks,
 audio
 };
 return result
}

 let input = `[!] *wrong input*
	
Ex : ${command} link/`

 if (!q) return m.reply(input)

 if (!(q.includes('https://'))) return m.reply(`url invalid, please input a valid url. Try with add http:// or https://`)
 if (!q.includes('tiktok.com')) return m.reply(`Invalid Tiktok URL.`)

 const {
 result
 } = await tiktok(q);
 m.reply(mess.wait)
 let no = 1
 for (let i of result) {
 // sky.sendMessage(m.chat, i, '', `Gambar ke - `, m)
 sky.sendMessage(from, { image: { url: i }, caption: `_Hasil_ *${no++}*`})
 }
}
break

case 'volvid': {
 const { TelegraPh } = require('./lib/uploader');
 const ffmpeg = require('fluent-ffmpeg');
 const fs = require('fs');
 
 const who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? sky.user.jid : m.sender;
 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';
 
 if (!mime || !mime.includes('video')) return m.reply(`Mana videonya bang?`);
 
 const volume = parseFloat(args[0]) || 1;
 if (isNaN(volume) || volume <= 0) return m.reply('Tentukan volume yang valid (contoh: 0.5 untuk setengah, 2 untuk dua kali lipat)');
 
 m.reply(mess.wait);
 
 try {
 const media = await sky.downloadAndSaveMediaMessage(q);
 const output = 'output.mp4';
 
 ffmpeg(media)
 .audioFilters(`volume=${volume}`)
 .on('start', (commandLine) => {
 console.log(`Spawned Ffmpeg with command: ${commandLine}`);
 })
 .on('error', async (err) => {
 console.error(`Error: ${err.message}`);
 await fs.promises.unlink(media).catch(console.error);
 return m.reply(`Error: ${err.message}`);
 })
 .on('end', async () => {
 console.log('Video processed');
 
 try {
 const url = await TelegraPh(output);
 await fs.promises.unlink(output);
 await fs.promises.unlink(media);
 
 sky.sendMessage(m.chat, { caption: `_Success To Change Video Volume_`, video: { url } }, { quoted: m });
 } catch (err) {
 console.error(`Error uploading video: ${err.message}`);
 await fs.promises.unlink(media).catch(console.error);
 return m.reply(`Error uploading video: ${err.message}`);
 }
 })
 .save(output);
 } catch (err) {
 console.error(`Error processing video: ${err.message}`);
 return m.reply(`Error processing video: ${err.message}`);
 }
}
break
case 'tt': case 'tiktok': case 'tiktoknowm': case 'tt': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
 if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
 db.data.users[m.sender].limit -= 10 // -1 limit
			 if (!text) throw 'Masukkan Query Link!'
			m.reply(mess.wait)
			axios.get(`https://widipe.com/download/ttdl?url=${q}`).then(({ data }) => {
				sky.sendMessage(m.chat, { video: { url: data.result.video[0] }, mimetype: 'video/mp4' })
			})			
			}
			break
case 'sky': {
 if (!text) return m.reply("_lu manggil gua_");

 const axios = require('axios');

 async function luminAi(teks, pengguna = null, prompt = null, modePencarianWeb = false, imageBuffer = null) {
 try {
 const data = { content: teks };
 if (pengguna !== null) data.user = pengguna;
 if (prompt !== null) data.prompt = prompt;
 data.webSearchMode = modePencarianWeb;
 if (imageBuffer !== null) data.imageBuffer = imageBuffer;

 const response = await axios.post("https://lumin-ai.xyz/", data);
 return response.data.result;
 } catch (error) {
 console.error('Terjadi kesalahan saat menggunakan LuminAI:', error);
 throw error; // Rethrow the error to handle it in the caller function
 }
 }

 const teks = args.join(' ');
 const pengguna = `${m.sender.split('@')[0]}`; 
 const prompt = `aku adalah orang yang bernama avosky atau iky aku tinggal di sebuah tempat yang bernama isekai dan aku di temani 100 harem dengan dada yang besar, dan 1 hal yang aku ingat adalah aku tidak akan membalas pesan orang dengan bahasa inggris aku hanya membalas dengan bahasa Indonesia`;
 const modePencarianWeb = false;

 try {
 let result;
 if (quoted && /image/.test(quoted.mimetype)) {
 const imageBuffer = await quoted.download();
 result = await luminAi(teks, pengguna, prompt, modePencarianWeb, imageBuffer);
 } else {
 result = await luminAi(teks, pengguna, prompt, modePencarianWeb);
 }
 m.reply(`${result}`);
 } catch (error) {
 m.reply('Terjadi kesalahan saat menggunakan LuminAI.');
 console.error('Error LuminAI:', error);
 }
}
break
case 'alldl': {
 if (!args.length) return m.reply('Tolong masukkan URL yang valid.');

 const url = args[0];

 async function alldl(url) {
 const req = {
 version: "7.14.6",
 commit: "2f4e43f",
 branch: "current",
 name: "olly",
 url: url,
 cors: 1,
 startTime: Date.now().toString()
 };

 const header = {
 'Accept': 'application/json',
 'Content-Type': 'application/json',
 'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, seperti Gecko) Chrome/126.0.0.0 Mobile Safari/537.36',
 'Referer': 'https://cobalt.tools/'
 };

 try {
 const resp = await fetch('https://api.cobalt.tools/api/json', {
 method: 'POST',
 headers: header,
 body: JSON.stringify(req)
 });

 if (resp.ok) {
 const data = await resp.json();
 return data;
 } else {
 const errorData = await resp.text(); // Mendapatkan pesan kesalahan dari respons
 return {
 status: false,
 message: 'Permintaan tidak dapat diproses',
 error: errorData
 };
 }
 } catch (error) {
 return {
 status: false,
 message: 'Kesalahan saat mengirim permintaan',
 error: error.message
 };
 }
 }

 alldl(url).then(result => {
 if (result.status === 'stream' && result.url) {
 sky.sendMessage(from, { 
 audio: { url: result.url }, 
 mimetype: "audio/mp4", 
 fileName: "Audio" 
 }, { quoted: m })
 .then(() => {
 console.log('Audio berhasil dikirim');
 })
 .catch(audioError => {
 console.error('Gagal mengirim audio:', audioError);
 sky.sendMessage(from, { 
 video: { url: result.url }, 
 mimetype: "video/mp4", 
 fileName: "Video" 
 }, { quoted: m })
 .then(() => {
 console.log('Video berhasil dikirim');
 })
 .catch(videoError => {
 console.error('Gagal mengirim video:', videoError);
 m.reply(`Gagal mengirim audio dan video: ${videoError.message}`);
 });
 });
 } else {
 m.reply(`Gagal mendownload audio: ${result.message || result.error}`);
 }
 }).catch(error => {
 m.reply(`Terjadi kesalahan: ${error.message}`);
 });
}
 break
case 'cekallmem': {
 let PhoneNum = require("awesome-phonenumber");
 let regionNames = new Intl.DisplayNames(["en"], {
 type: "region",
 });
 let data = await sky.groupMetadata(m.chat);
 let arr = [];
 for (let i of data.participants) {
 arr.push({
 number: i.id,
 code: regionNames.of(PhoneNum("+" + i.id.split("@")[0]).getRegionCode("internasional")),
 });
 }
 let json = {};
 for (let contact of arr) {
 let country = contact.code;
 json[country] = (json[country] || 0) + 1;
 }
 let countryCounts = Object.keys(json).map((country) => ({
 name: country,
 total: json[country],
 }));
 let totalSum = countryCounts.reduce((acc, country) => acc + country.total, 0);
 let totalRegion = [...new Set(arr.map(a => a.code))]
 let hasil = countryCounts.map(({
 name,
 total
 }) => ({
 name,
 total,
 percentage: ((total / totalSum) * 100).toFixed(2) + '%'
 }));
 let cap = `┌─ _Jumlah Member_
│ > 𝘕𝘢𝘮𝘦 : ${data.subject}
│ > 𝘛𝘰𝘵𝘢𝘭 : ${data.participants.length}
│ > 𝘛𝘰𝘵𝘢𝘭 𝘙𝘦𝘨𝘪𝘰𝘯 : ${totalRegion.length}
└───────────────

┌─ _Asal Member_
${hasil.sort((b, a) => a.total - b.total).map(a => `│ > 𝘙𝘦𝘨𝘪𝘰𝘯 : ${a.name} > [ ${a.percentage} ]
│ > 𝘛𝘰𝘵𝘢𝘭 : ${a.total} 𝘔𝘦𝘮𝘣𝘦𝘳`).join("\n")}
└───────────────`
 m.reply(`${cap}`)
 }
 break
 case 'maker': {
  version = text.split(' | ')[0] ? text.split(' | ')[0] : '-'
  ky = text.split(' | ')[1] ? text.split(' | ')[1] : '-'
  if (!text) {
    m.reply('Harap berikan teks untuk logo\n\n> maker v1 | text.');
    return;
  }
  let url = '';
  switch (version) {
    case 'v1':
      url = `https://dynamic.brandcrowd.com/asset/logo/04ca85c5-a4c1-4582-8296-7fb8cbdf7df1/logo?v=4&text=${ky}`;
      break;
    case 'v2':
      url = `https://dynamic.brandcrowd.com/asset/logo/063a3d53-d7bb-4abb-8b20-3e45ae7c61ac/logo?v=4&text=${ky}`;
      break;
    case 'v3':
      url = `https://dynamic.brandcrowd.com/asset/logo/065b4535-d123-4261-accb-2f21e3eac3cf/logo?v=4&text=${ky}`;
      break;
    case 'v4':
      url = `https://dynamic.brandcrowd.com/asset/logo/09699c93-f687-4c58-b6dc-cb8010de7df9/logo?v=4&text=${ky}`;
      break;
    case 'v5':
      url = `https://dynamic.brandcrowd.com/asset/logo/097b9969-5019-433a-9a3f-d2e097b50e99/logo?v=4&text=${ky}`;
      break;
    case 'v6':
      url = `https://dynamic.brandcrowd.com/asset/logo/0c963355-e735-4cdd-bec8-1373ba2a222e/logo?v=4&text=${ky}`;
      break;
    case 'v7':
      url = `https://dynamic.brandcrowd.com/asset/logo/0cd45dda-e1e6-46bc-9f0d-b49a5d3c3667/logo?v=4&text=${ky}`;
      break;
    case 'v8':
      url = `https://dynamic.brandcrowd.com/asset/logo/10cd8160-2b8d-41c5-87cc-f683a853d5d9/logo?v=4&text=${ky}`;
      break;
    case 'v9':
      url = `https://dynamic.brandcrowd.com/asset/logo/163db786-9e2a-494a-a996-de565ae52f83/logo?v=4&text=${ky}`;
      break;
    case 'v10':
      url = `https://dynamic.brandcrowd.com/asset/logo/1e47fc81-0c56-45d5-aa5e-07006260dfbc/logo?v=4&text=${ky}`;
      break;
    case 'v11':
      url = `https://dynamic.brandcrowd.com/asset/logo/1fd728fb-fdb3-4407-a7da-fe55bfcb5fb0/logo?v=4&text=${ky}`;
      break;
    case 'v12':
      url = `https://dynamic.brandcrowd.com/asset/logo/236a12ee-2b79-4b58-b9e4-5536f5e93db7/logo?v=4&text=${ky}`;
      break;
    case 'v13':
      url = `https://dynamic.brandcrowd.com/asset/logo/2648d66c-fec5-488f-9626-06991ca917e0/logo?v=4&text=${ky}`;
      break;
    case 'v14':
      url = `https://dynamic.brandcrowd.com/asset/logo/362270db-6933-4ccc-8c11-25b2fe97f023/logo?v=4&text=${ky}`;
      break;
    case 'v15':
      url = `https://dynamic.brandcrowd.com/asset/logo/4a0312ef-6f47-421d-9d10-354c27de8e0f/logo?v=4&text=${ky}`;
      break;
    case 'v16':
      url = `https://dynamic.brandcrowd.com/asset/logo/50dd554f-ffed-4496-b770-870fef2aefe5/logo?v=4&text=${ky}`;
      break;
    case 'v17':
      url = `https://dynamic.brandcrowd.com/asset/logo/5ed1f95d-736f-4fe3-9aec-d0a8875dee17/logo?v=4&text=${ky}`;
      break;
    case 'v18':
      url = `https://dynamic.brandcrowd.com/asset/logo/6458e177-55ec-4b2d-8be7-4094431378ad/logo?v=4&text=${ky}`;
      break;
    case 'v19':
      url = `https://dynamic.brandcrowd.com/asset/logo/672fc6e7-e445-47e3-9391-2e1d1452960a/logo?v=4&text=${ky}`;
      break;
    case 'v20':
      url = `https://dynamic.brandcrowd.com/asset/logo/7229c0d6-cc4f-4e47-87b2-3b01285f502d/logo?v=4&text=${ky}`;
      break;
    case 'v21':
      url = `https://dynamic.brandcrowd.com/asset/logo/73113e56-8ac2-484e-9272-06759b7d51e2/logo?v=4&text=${ky}`;
      break;
    case 'v22':
      url = `https://dynamic.brandcrowd.com/asset/logo/7429f9b9-562f-439b-86cd-81f04d76d883/logo?v=4&text=${ky}`;
      break;
    case 'v23':
      url = `https://dynamic.brandcrowd.com/asset/logo/746604d3-8da9-4488-8fa9-bf301d62ea0e/logo?v=4&text=${ky}`;
      break;
    case 'v24':
      url = `https://dynamic.brandcrowd.com/asset/logo/867bea51-793c-4b09-b13f-44c9053b6754/logo?v=4&text=${ky}`;
      break;
    case 'v25':
      url = `https://dynamic.brandcrowd.com/asset/logo/882f41c2-98ee-43f2-bf07-f033cf1c3320/logo?v=4&text=${ky}`;
      break;
    case 'v26':
      url = `https://dynamic.brandcrowd.com/asset/logo/8a2d089b-7b87-4979-906e-7731b594bd4b/logo?v=4&text=${ky}`;
      break;
    case 'v27':
      url = `https://dynamic.brandcrowd.com/asset/logo/8bb23d1a-7fb2-4f5d-ba6c-2a9bd13cc673/logo?v=4&text=${ky}`;
      break;
    case 'v28':
      url = `https://dynamic.brandcrowd.com/asset/logo/8dcc7e92-c12c-40df-8c8b-9f9db93b11a0/logo?v=4&text=${ky}`;
      break;
    case 'v29':
      url = `https://dynamic.brandcrowd.com/asset/logo/8f825f13-dadf-442c-b9e5-a1daa03611c4/logo?v=4&text=${ky}`;
      break;
    case 'v30':
      url = `https://dynamic.brandcrowd.com/asset/logo/8ffdc28c-ea27-4b0c-89c3-3f9a9b40e5fd/logo?v=4&text=${ky}`;
      break;
    case 'v31':
      url = `https://dynamic.brandcrowd.com/asset/logo/912b6462-49d3-435a-959e-5c5f3254d6c4/logo?v=4&text=${ky}`;
      break;
    case 'v32':
      url = `https://dynamic.brandcrowd.com/asset/logo/924d12da-4a2b-46b3-82cd-bc9b38a519d0/logo?v=4&text=${ky}`;
      break;
    case 'v33':
      url = `https://dynamic.brandcrowd.com/asset/logo/9459965a-f378-430a-8cb9-62778fec5713/logo?v=4&text=${ky}`;
      break;
    case 'v34':
      url = `https://dynamic.brandcrowd.com/asset/logo/9608708e-7907-4bae-892c-87964aee0454/logo?v=4&text=${ky}`;
      break;
        case 'v35':
      url = `https://dynamic.brandcrowd.com/asset/logo/963fcb8b-1ba3-46f1-82bd-8e92a5a024d1/logo?v=4&text=${ky}`;
      break;
    case 'v36':
      url = `https://dynamic.brandcrowd.com/asset/logo/99c6feef-cee4-47b3-afc7-1f192e7f48f4/logo?v=4&text=${ky}`;
      break;
    case 'v37':
      url = `https://dynamic.brandcrowd.com/asset/logo/a075034f-0363-4af4-877f-aba47a7c059d/logo?v=4&text=${ky}`;
      break;
    case 'v38':
      url = `https://dynamic.brandcrowd.com/asset/logo/a428ed89-5ed1-4b1d-b095-2ee98ae54b40/logo?v=4&text=${ky}`;
      break;
    case 'v39':
      url = `https://dynamic.brandcrowd.com/asset/logo/afa0be93-d4ae-46d5-b741-64bd3b4b6148/logo?v=4&text=${ky}`;
      break;
    case 'v40':
      url = `https://dynamic.brandcrowd.com/asset/logo/b0fb81f5-59a4-4197-947f-26037441ea2f/logo?v=4&text=${ky}`;
      break;
    case 'v41':
      url = `https://dynamic.brandcrowd.com/asset/logo/b1826077-0a6f-403d-939e-b445c334c470/logo?v=4&text=${ky}`;
      break;
    case 'v42':
      url = `https://dynamic.brandcrowd.com/asset/logo/b3581ffd-a127-465b-b880-bd3770b85aad/logo?v=4&text=${ky}`;
      break;
    case 'v43':
      url = `https://dynamic.brandcrowd.com/asset/logo/b5be66f6-a6a6-42dc-ab67-de8f80e96291/logo?v=4&text=${ky}`;
      break;
    case 'v44':
      url = `https://dynamic.brandcrowd.com/asset/logo/b5e150af-101d-4e96-9518-dff66548dc31/logo?v=4&text=${ky}`;
      break;
    case 'v45':
      url = `https://dynamic.brandcrowd.com/asset/logo/b8b4fc21-d1b6-4ee1-a6f3-4410a49e123a/logo?v=4&text=${ky}`;
      break;
    case 'v46':
      url = `https://dynamic.brandcrowd.com/asset/logo/b95516e4-645d-4249-b81b-b9ca65bd2087/logo?v=4&text=${ky}`;
      break;
    case 'v47':
      url = `https://dynamic.brandcrowd.com/asset/logo/b97103b8-3b7c-4f1d-8c91-451c11e8cde3/logo?v=4&text=${ky}`;
      break;
    case 'v48':
      url = `https://dynamic.brandcrowd.com/asset/logo/bbf8e7fe-13c2-420c-bb2c-9c059744d599/logo?v=4&text=${ky}`;
      break;
    case 'v49':
      url = `https://dynamic.brandcrowd.com/asset/logo/bd9069cc-408d-4f00-90b4-9d6c96bc0b3d/logo?v=4&text=${ky}`;
      break;
    case 'v50':
      url = `https://dynamic.brandcrowd.com/asset/logo/be638691-3065-45cb-b90c-263945cd0177/logo?v=4&text=${ky}`;
      break;
    case 'v51':
      url = `https://dynamic.brandcrowd.com/asset/logo/c054d202-df4b-466d-8477-2b8690030ce5/logo?v=4&text=${ky}`;
      break;
    case 'v52':
      url = `https://dynamic.brandcrowd.com/asset/logo/c1e008df-5207-463e-a6a7-a823174d0bda/logo?v=4&text=${ky}`;
      break;
    case 'v53':
      url = `https://dynamic.brandcrowd.com/asset/logo/cc9a22ce-f65c-40ff-9eac-43c26817f44a/logo?v=4&text=${ky}`;
      break;
    case 'v54':
      url = `https://dynamic.brandcrowd.com/asset/logo/d588330f-b11c-4482-baff-49323323a8c0/logo?v=4&text=${ky}`;
      break;
    case 'v55':
      url = `https://dynamic.brandcrowd.com/asset/logo/e32a0e7e-df48-4b33-bccf-1f74d395d322/logo?v=4&text=${ky}`;
      break;
    case 'v56':
      url = `https://dynamic.brandcrowd.com/asset/logo/ee1930f1-09a8-4d5e-bbe9-e43547bb7f64/logo?v=4&text=${ky}`;
      break;
    case 'v57':
      url = `https://dynamic.brandcrowd.com/asset/logo/fde5293a-c69b-4d77-9ec8-f3d6797d2b15/logo?v=4&text=${ky}`;
      break;
    case 'v58':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=amped-logo&doScale=true&scaleWidth=800&scaleHeight=500&text=${ky}`;
      break;
    case 'v59':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=crafts-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&text=${ky}`;
      break;
    case 'v60':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&fillColor1Color=%23f2aa4c&fillColor2Color=%23f2aa4c&fillColor3Color=%23f2aa4c&fillColor4Color=%23f2aa4c&fillColor5Color=%23f2aa4c&fillColor6Color=%23f2aa4c&fillColor7Color=%23f2aa4c&fillColor8Color=%23f2aa4c&fillColor9Color=%23f2aa4c&fillColor10Color=%23f2aa4c&fillOutlineColor=%23f2aa4c&fillOutline2Color=%23f2aa4c&backgroundColor=%23101820&text=${ky}`;
      break;
    case 'v61':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=${ky}`;
      break;
    case 'v62':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=water-logo&script=water-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextColor=%23000&shadowGlowColor=%23000&backgroundColor=%23000&text=${ky}`;
      break;
    case 'v63':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=arcade-logo&text=${ky}`;
      break;
    case 'v64':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=dance-logo&text=${ky}`;
      break;
    case 'v65':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=emperor-logo&text=${ky}`;
      break;
    case 'v66':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=flame-logo&text=${ky}`;
      break;
    case 'v67':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=matrix-logo&text=${ky}`;
      break;
    case 'v68':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=robot-logo&text=${ky}`;
      break;
        case 'v69':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=robot-logo&text=${ky}`;
      break;
    case 'v70':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=shadow-logo&text=${ky}`;
      break;
    case 'v71':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=silhouette-logo&text=${ky}`;
      break;
    case 'v72':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=smooth-logo&text=${ky}`;
      break;
    default:
      m.reply('Versi tidak dikenal. Silakan gunakan versi dari v1 hingga v72.');
      return;
  }  
  sky.sendFile(m.chat, url, 'maker.jpg', `Logo versi ${version}`, m);
}
break
case 'sfull': {
 const { exec } = require('child_process');
 const fs = require('fs');
 const path = require('path');

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';

 if (!mime || !mime.includes('image')) return m.reply(`Mana gambarnya bang?`);
 m.reply(mess.wait);

 try {
 const media = await sky.downloadAndSaveMediaMessage(q);
 const output = 'output.webp'; // Nama file output

 // Menggunakan ffmpeg untuk mengonversi gambar menjadi stiker dengan padding
 exec(`ffmpeg -i ${media} -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2" -f webp -frames:v 1 ${output}`, (err, stdout, stderr) => {
 if (err) {
 console.error(`Error: ${err.message}`);
 return m.reply(`Error: ${err.message}`);
 }

 console.log(`Stiker processed: ${stdout}`);

 // Mengirim stiker yang telah dibuat
 sky.sendFile(m.chat, output, 'sticker.webp', '', m, false, { asSticker: true });

 // Menghapus file setelah selesai
 fs.unlinkSync(output);
 fs.unlinkSync(media);
 });
 } catch (err) {
 console.error(`Error: ${err.message}`);
 return m.reply(`Error: ${err.message}`);
 }
}
break
case 'text2img': {
 const fetch = require('node-fetch');
 
 async function text2img(prompt) {
 const vredenapi = "https://ai-api.magicstudio.com/api/ai-art-generator";
 const body = `prompt=${encodeURIComponent(prompt)}`;

 try {
 const response = await fetch(vredenapi, {
 method: 'POST',
 headers: {
 'Content-Type': 'application/x-www-form-urlencoded'
 },
 body: body
 });

 if (response.ok) {
 const imageBuffer = await response.buffer();
 return imageBuffer;
 } else {
 const responseError = await response.text();
 throw new Error(`Gagal mengambil gambar. Kode status: ${response.status}, Error: ${responseError}`);
 }
 } catch (error) {
 throw error;
 }
 }

 // Memanggil fungsi text2img dengan argumen prompt yang diberikan (q)
 text2img(`${q}`).then((imageBuffer) => {
 sky.sendMessage(m.chat, { image: imageBuffer, caption: `_doneeeee_` }, { quoted: m });
 }).catch((error) => {
 m.reply(`Error: ${error.message}`);
 });
}
break
case 'play2': {
 if (!text) return m.reply("_Lagu apa_?");

 const Ytdl = require('./lib/y2mate');
 const yts = require('yt-search');
 const axios = require('axios');
 const stream = require('stream');

 await sky.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 try {
 // Search for the video using yts
 const searchResults = await yts(text);
 const videos = searchResults.all.filter(v => v.type === 'video');
 if (!videos.length) {
 await sky.sendMessage(m.chat, 'No videos found for your query.', { quoted: m });
 return;
 }

 // Get the first video result
 const video = videos[0];
 const ytdl = new Ytdl();
 const result = await ytdl.play(video.url);
 const title = result.title;

 // Choose the highest quality available audio
 const highestQuality = Object.keys(result.audio).reduce((a, b) => (a > b ? a : b));
 const audioUrl = result.audio[highestQuality].url;

 // Stream the audio directly
 const audioStream = (await axios.get(audioUrl, { responseType: 'stream' })).data;
 const audioBuffer = [];

 audioStream.on('data', chunk => audioBuffer.push(chunk));
 audioStream.on('end', async () => {
 const buffer = Buffer.concat(audioBuffer);
 await sky.sendMessage(m.chat, {
 audio: buffer,
 mimetype: 'audio/mpeg',
 ptt: false, // Set to true if you want to send it as a voice note
 contextInfo: {
 externalAdReply: {
 title: title,
 body: `Audio quality: ${highestQuality}`,
 mediaType: 2,
 mediaUrl: audioUrl,
 sourceUrl: audioUrl,
 renderLargerThumbnail: true
 }
 }
 });

 await sky.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 });

 } catch (error) {
 console.error('Error:', error);
 if (error.response && error.response.status === 403) {
 await sky.sendMessage(m.chat, 'Download forbidden. Try another video or check your connection.', { quoted: m });
 } else {
 await sky.sendMessage(m.chat, 'Error occurred while processing your request.', { quoted: m });
 }
 }
}
break
case 'openport': {
 const net = require('net');
 const websiteUrl = args[0];

 if (!websiteUrl) {
 m.reply('Tentukan URL website yang ingin diperiksa portnya.');
 return;
 }

 // Daftar port umum dan nama portnya
 const ports = {
 21: 'FTP',
 22: 'SSH',
 23: 'Telnet',
 25: 'SMTP',
 53: 'DNS',
 80: 'HTTP',
 110: 'POP3',
 143: 'IMAP',
 443: 'HTTPS',
 587: 'SMTP (secure)',
 993: 'IMAP (secure)',
 995: 'POP3 (secure)',
 };

 let openPorts = [];

 const checkPort = (port) => {
 return new Promise((resolve) => {
 const socket = new net.Socket();
 const timeout = 2000; // 2 detik

 socket.setTimeout(timeout);
 socket.on('connect', () => {
 openPorts.push(port);
 socket.destroy();
 resolve();
 });
 socket.on('timeout', () => {
 socket.destroy();
 resolve();
 });
 socket.on('error', () => {
 resolve();
 });
 socket.connect(port, websiteUrl);
 });
 };

 const checkAllPorts = async () => {
 for (const port of Object.keys(ports)) {
 await checkPort(port);
 }

 if (openPorts.length === 0) {
 m.reply(`Tidak ada port terbuka pada ${websiteUrl}.`);
 } else {
 let openPortsDetails = openPorts.map(port => `${port} (${ports[port]})`).join('\n');
 m.reply(`Port terbuka pada ${websiteUrl}:\n${openPortsDetails}`);
 }
 };

 checkAllPorts();
}
break
case 'image-gen': {
 if (!text) throw `prompt | style`
ky = text.split(' | ')[0] ? text.split(' | ')[0] : '-'
kyy = text.split(' | ')[1] ? text.split(' | ')[1] : '-'
prompt = `${ky}`;
 // Definisikan fungsi animagine di dalam case
 async function animagine(options = {}) {
 return new Promise(async (resolve, reject) => {
 try {
 let {
 prompt = `${ky}`,
 negative = "Not Real",
 style = `${kyy}`,
 sampler = "Euler a",
 ratio = "896 x 1152",
 quality = "Standard",
 width = "1024",
 height = "1024",
 } = options;
 const BASE_URL = "https://linaqruf-animagine-xl.hf.space";
 const session_hash = Math.random().toString(36).substring(2);

 // Checker
 if (
 !/\(None\)|Cinematic|Photographic|Anime|Manga|Digital Art|Pixel art|Fantasy art|Neonpunk|3D Model/.test(
 style
 )
 )
 style = "Anime";
 if (
 !/DDIM|Euler a|Euler|DPM\+\+ 2M Karras|DPM\+\+ 2M SDE Karras|DPM\+\+ SDE Karras/.test(
 sampler
 )
 )
 sampler = "Euler a";
 if (!/\(none\)|Light|Standard|Heavy/.test(quality)) quality = "Standard";
 if (
 !/Custom|640 x 1536|832 x 1216|1024 x 1024|1152 x 896|1344 x 768|768 x 1344|896 x 1152|1216 x 832|1536 x 640/.test(
 ratio
 )
 )
 ratio = "896 x 1152";
 if (ratio === "Custom") {
 if (!width || isNaN(width) || +width > 2048)
 return reject("Enter Valid Image Width Below 2048");
 if (!height || isNaN(height) || +height > 2048)
 return reject("Enter Valid Image Height Below 2048");
 }

 // Headers
 const headers = {
 origin: BASE_URL,
 referer: BASE_URL + "/?",
 "user-agent":
 "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
 "content-type": "application/json",
 "Content-Length": "application/json".length,
 };

 // Token
 const { data: token } = await fetch(BASE_URL + "/run/predict", {
 method: "POST",
 headers,
 body: JSON.stringify({
 data: [0, true],
 event_data: null,
 fn_index: 4,
 session_hash,
 trigger_id: 6,
 }),
 }).then((v) => v.json());

 // Join
 await fetch(BASE_URL + "/queue/join?", {
 method: "POST",
 headers,
 body: JSON.stringify({
 data: [
 prompt,
 negative,
 token[0],
 width,
 height,
 7,
 28, // Step
 sampler, // Sampler
 ratio, // Aspect ratio
 style, // Style
 quality, // Quality
 false,
 0.55,
 1.5,
 true,
 ],
 event_data: null,
 fn_index: 5,
 session_hash,
 trigger_id: 7,
 }),
 }).then((v) => v.json());

 // Generate Images
 const stream = await fetch(
 BASE_URL + "/queue/data?" + new URLSearchParams({ session_hash })
 ).then((v) => v.body);

 // Handle Stream
 stream.on("data", (v) => {
 const data = JSON.parse(v.toString().split("data: ")[1]);
 if (data.msg !== "process_completed") return;
 if (!data.success) return reject("Image Generation Failed!");
 return resolve(data.output.data[0]);
 });
 } catch (e) {
 reject(e);
 }
 });
 }

 try {
 const result = await animagine({ prompt });

 if (result && result[0] && result[0].image && result[0].image.url) {
 // Mengirim gambar hasil ke pengguna
 sky.sendFile(m.chat, result[0].image.url, 'result.png', 'Ini gambar yang dihasilkan berdasarkan prompt Anda.');
 } else {
 m.reply('Gambar tidak dapat dihasilkan.');
 }
 } catch (error) {
 m.reply('Terjadi kesalahan saat menghasilkan gambar: ' + error.message);
 }
}
break
case 'tourl8': {
 const FormData = require('form-data');
 const axios = require('axios');
 const fs = require('fs');
 const path = require('path');
 const fileType = require('file-type'); // Mengimpor file-type

 async function uploadToStorage(mediaPath) {
 try {
 const buffer = fs.readFileSync(mediaPath);
 const mime = await fileType.fromBuffer(buffer); // Menggunakan fromBuffer
 if (!mime) throw new Error("Cannot detect file type");
 const form = new FormData();
 form.append("file", buffer, `file-${Date.now()}.${mime.ext}`);
 const response = await axios.post("https://storage.netorare.codes/upload", form, {
 headers: {
 "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
 "Referer": "https://storage.netorare.codes/",
 ...form.getHeaders(),
 },
 });
 if (!response.data || !response.data.filePath) {
 throw new Error('Failed to get file URL from response');
 }
 return {
 filePath: response.data.filePath,
 uploadDate: response.data.uploadDate,
 };
 } catch (err) {
 throw new Error(`Upload failed: ${err.message}`);
 }
 }

 try {
 m.reply('loading');
 let media = await sky.downloadAndSaveMediaMessage(qmsg);
 if (fs.statSync(media).size > 350000000) {
 m.reply('File terlalu besar, maksimal 350MB');
 return;
 }
 let data = await uploadToStorage(media);
 m.reply(`Link: ${data.filePath}\nUpload Date: ${data.uploadDate}`); 
 fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Terjadi kesalahan: ${err.message}`);
 }
}
break

case 'fully': {
 const sharp = require('sharp');
 const fs = require('fs');

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';

 if (!mime || !mime.includes('image')) return m.reply(`Mana gambarnya bang?`);
 m.reply(mess.wait);

 try {
 const media = await sky.downloadAndSaveMediaMessage(q);
 const output = 'output_square.jpg'; // Nama file output

 // Menggunakan sharp untuk mengubah gambar lonjong menjadi kotak tanpa cropping
 sharp(media)
 .resize(1080, 1080, { fit: 'fill' }) // Resize gambar ke ukuran kotak 1080x1080 piksel tanpa menjaga aspek rasio
 .toFile(output)
 .then(() => {
 // Mengirim gambar yang telah diubah sebagai stiker
 sky.sendFile(m.chat, output, '', '', m)
 .then(() => {
 // Menghapus file setelah selesai
 fs.unlinkSync(output);
 fs.unlinkSync(media);
 })
 .catch(err => {
 console.error(`Error: ${err.message}`);
 m.reply(`Error: ${err.message}`);
 });
 })
 .catch(err => {
 console.error(`Error: ${err.message}`);
 m.reply(`Error: ${err.message}`);
 });
 } catch (err) {
 console.error(`Error: ${err.message}`);
 m.reply(`Error: ${err.message}`);
 }
}
break
case 'fillvideo': {
 const { TelegraPh } = require('./lib/uploader');
 const ffmpeg = require('fluent-ffmpeg');
 const fs = require('fs');

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';

 if (!mime || !mime.includes('video')) return m.reply(`Mana videonya bang?`);
 m.reply(mess.wait);

 try {
 const media = await sky.downloadAndSaveMediaMessage(q);
 const output = 'output.mp4'; // Nama file output

 // Menggunakan ffmpeg untuk mengubah ukuran video menjadi kotak
 ffmpeg(media)
 .videoCodec('libx264')
 .audioCodec('aac')
 .videoFilter([
 'scale=1280:1280:force_original_aspect_ratio=increase',
 'crop=1280:1280'
 ]) // Mengubah ukuran dan memotong video
 .format('mp4')
 .on('end', async () => {
 console.log('Video processing finished.');

 // Mengunggah video yang telah diproses
 const url = await TelegraPh(output);
 sky.sendVideoAsSticker(m.chat, url, m, { packname: global.packname, author: global.author })
 
 // Menghapus file setelah selesai
 fs.unlinkSync(output);
 fs.unlinkSync(media);
 })
 .on('error', (err) => {
 console.error(`Error: ${err.message}`);
 m.reply(`Error: ${err.message}`);
 })
 .save(output);
 } catch (err) {
 console.error(`Error: ${err.message}`);
 return m.reply(`Error: ${err.message}`);
 }
}
break
case 'bukalapak': {
 if (!text) throw `cari apa?`
 function BukaLapak(search) {
 return new Promise(async (resolve, reject) => {
 try {
 const { data } = await axios.get(`https://www.bukalapak.com/products?from=omnisearch&from_keyword_history=false&search[keywords]=${q}&search_source=omnisearch_keyword&source=navbar`, {
 headers: {
 "user-agent": 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0'
 }
 });
 const $ = cheerio.load(data);
 const dat = [];
 $('div.bl-flex-item.mb-8').each((i, u) => {
 const a = $(u).find('observer-tracker > div > div');
 const img = $(a).find('div > a > img').attr('src');
 if (!img) return;

 const link = $(a).find('.bl-thumbnail--slider > div > a').attr('href');
 const title = $(a).find('.bl-product-card__description-name > p > a').text().trim();
 const harga = $(a).find('div.bl-product-card__description-price > p').text().trim();
 const rating = $(a).find('div.bl-product-card__description-rating > p').text().trim();
 const terjual = $(a).find('div.bl-product-card__description-rating-and-sold > p').text().trim();

 const dari = $(a).find('div.bl-product-card__description-store > span:nth-child(1)').text().trim();
 const seller = $(a).find('div.bl-product-card__description-store > span > a').text().trim();
 const link_sel = $(a).find('div.bl-product-card__description-store > span > a').attr('href');

 const res_ = {
 title: title,
 rating: rating ? rating : 'No rating yet',
 terjual: terjual ? terjual : 'Not yet bought',
 harga: harga,
 image: img,
 link: link,
 store: {
 lokasi: dari,
 nama: seller,
 link: link_sel
 }
 };

 dat.push(res_);
 });
 if (dat.every(x => x === undefined)) return resolve({ message: 'Tidak ada result!' });
 resolve(dat);
 } catch (err) {
 console.error(err);
 reject(err);
 }
 });
 }
 BukaLapak(searchQuery).then(results => {
 if (results.message) {
 m.reply(results.message);
 return;
 } 
 let replyText = `Hasil pencarian untuk "${q}":\n\n`;
 results.forEach((item, index) => {
 replyText += `*${index + 1}. ${item.title}*\n`;
 replyText += `Harga: ${item.harga}\n`;
 replyText += `Rating: ${item.rating}\n`;
 replyText += `Terjual: ${item.terjual}\n`;
 replyText += `Link: ${item.link}\n`;
 replyText += `Store: ${item.store.nama} - ${item.store.lokasi}\n`;
 replyText += `Image: ${item.image}\n\n`;
 });
 m.reply(replyText);
 }).catch(err => {
 m.reply('Terjadi kesalahan saat mencari produk.');
 console.error(err);
 });
}
break
case 'menusearch': {
 m.reply(`
 ≫ MENU SEARCH

 ┌ .PLAY
 │ .YTS
 │ .PLAYPTV
 │ .PLAYVID
 │ .GETMUSIC
 │ .GETVIDEO
 │ .GOOGLE
 │ .GIMAGE
 │ .PINTEREST
 │ .WALLPAPER
 │ .WIKIMEDIA
 │ .YTSEARCH
 │ .RINGTONE
 │ .IGSTALK
 │ .TTSTALK
 │ .GHSTALK
 │ .MLSTALK
 │ .PLAYSTORE
 │ .GSMARENA
 │ .JADWALBIOSKOP
 │ .NOWPLAYINGBIOSKOP
 │ .KISAHNABI
 │ .KBBI
 │ .ROBOGURU
 │ .BRAINLY
 │ .ALQURAN
 │ .TAFSIRSURAH
 │ .JADWALBOLA
 │ .JADWALSOLAT
 │ .JADWALTV
 │ .JADWALTVNOW
 │ .CNNINDONESIA
 │ .CNNNASIONAL
 │ .CNNINTERNASIONAL
 │ .INFOGEMPA
 │ .INFOCUACA
 │ .KODEPOS
 │ .AI
 │ .GBARD
 │ .CARISTICKER
 │ .AINIME
 │ .AIDIFF
 │ .AKAR
 │ .KALI
 │ .PANGKAT
 │ .CREATE
 │ .AINIME2
 │ .NPM
 │ .SEARCHANIME
 │ .QUOTEMAKER
 │ .SKY
 │ .ABOUTNUMBER
 │ .FACTNUMBER
 │ .JOKEQUOTE
 │ .DEFINISI
 │ .INFOMOVIE
 │ .ESTIMASI
 │ .BERITA
 │ .TEKNOLOGI
 │ .HAPPYMOD
 │ .WATTPAD
 │ .JARAK
 │ .IKY
 │ .BUGHUNTER
 │ .IPINFO
 │ .QUOTE
 │ .TOXICHECK
 │ .RESEP
 │ .AYAT
 │ .BUKALAPAK
 │ .CARISURAH
 │ .ANIMELAST
 │ .BBCNEWS
 │ .INFONEGARA
 │ .KAMUS
 │ .IMDB
 └ .SINONIM
 `)
}
break
case 'textpro': {
 async function textpro(url, text) {
 if (!/^https:\/\/textpro\.me\/.+\.html$/.test(url)) {
 throw new Error("Url Salah!!");
 }

 const geturl = await fetch(url, {
 method: "GET",
 headers: {
 "User-Agent": "GoogleBot",
 },
 });

 const caritoken = await geturl.text();

 // Periksa apakah ada header 'set-cookie'
 const setCookieHeader = geturl.headers.get("set-cookie");
 if (!setCookieHeader) {
 throw new Error("Header 'set-cookie' tidak ditemukan!");
 }

 // Parse cookies dari header 'set-cookie'
 let hasilcookie = setCookieHeader
 .split(",")
 .map((v) => cookie.parse(v))
 .reduce((a, c) => {
 return { ...a, ...c };
 }, {});
 hasilcookie = {
 __cfduid: hasilcookie.__cfduid,
 PHPSESSID: hasilcookie.PHPSESSID,
 };
 hasilcookie = Object.entries(hasilcookie)
 .map(([name, value]) => cookie.serialize(name, value))
 .join("; ");

 const $ = cheerio.load(caritoken);
 const token = $('input[name="token"]').attr("value");
 if (!token) {
 throw new Error("Token tidak ditemukan dalam HTML!");
 }

 const form = new FormData();
 if (typeof text === "string") text = [text];
 for (let texts of text) form.append("text[]", texts);
 form.append("submit", "Go");
 form.append("token", token);
 form.append("build_server", "https://textpro.me");
 form.append("build_server_id", 1);

 const geturl2 = await fetch(url, {
 method: "POST",
 headers: {
 Accept: "*/*",
 "Accept-Language": "en-US,en;q=0.9",
 "User-Agent": "GoogleBot",
 Cookie: hasilcookie,
 ...form.getHeaders(),
 },
 body: form.getBuffer(),
 });

 const caritoken2 = await geturl2.text();
 const token2 = /<div.*?id="form_value".+>(.*?)<\/div>/.exec(caritoken2);
 if (!token2) {
 throw new Error("Token Tidak Ditemukan dalam respons POST!");
 }

 const prosesimage = await fetch(
 "https://textpro.me/create-",
 {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Cookie: hasilcookie,
 },
 body: JSON.stringify(JSON.parse(token2[1])),
 }
 );

 const hasil = await prosesimage.json();
 return `https://textpro.me${hasil.fullsize_image}`;
 }

 const [url, ...queryParts] = args;
 const query = queryParts.join(" ");
 
 if (!url || !query) {
 m.reply('Harap masukkan URL dan teks untuk diproses.');
 break;
 }

 try {
 const resultUrl = await textpro(url, query);
 // Kirim hasil dengan sky.sendFile
 sky.sendFile(m.chat, resultUrl, 'result.png', 'Hasil dari Textpro', m);
 } catch (error) {
 m.reply(`Terjadi kesalahan: ${error.message}`);
 }
}
 break
case 'tourl9': {
 const fetch = require('node-fetch');
 const fileType = require('file-type');
 const FormData = require('form-data');
 const fs = require('fs');

 async function nullbyte(mediaPath) {
 try {
 const buffer = fs.readFileSync(mediaPath);
 const { ext, mime } = await fileType.fromBuffer(buffer) || {};
 if (!ext || !mime) throw new Error("Cannot detect file type");

 const formData = new FormData();
 formData.append("file", buffer, {
 filename: `file-${Date.now()}.${ext}`,
 contentType: mime,
 });

 const response = await fetch("http://0x0.st", {
 method: "POST",
 body: formData,
 headers: {
 "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
 ...formData.getHeaders(),
 },
 });

 if (!response.ok) {
 const errorText = await response.text();
 throw new Error(`Upload failed with status ${response.status}: ${errorText}`);
 }

 const fileUrl = await response.text();
 return fileUrl;
 } catch (error) {
 throw new Error(`Upload failed: ${error.message}`);
 }
 }

 try {
 m.reply('Sedang memuat...');

 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 if (fs.statSync(media).size > 350000000) {
 m.reply('File terlalu besar, maksimal 350MB');
 return;
 }

 let url = await nullbyte(media);
 m.reply(`Link: ${url}`);

 fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Terjadi kesalahan saat mengunggah file: ${err.message}`);
 }
}
break
case 'tourl11': {
 const fetch = require('node-fetch');
 const fileType = require('file-type');
 const FormData = require('form-data');
 const fs = require('fs');

 async function fileDitch(mediaPath) {
 try {
 const buffer = fs.readFileSync(mediaPath);
 const { ext, mime } = await fileType.fromBuffer(buffer) || {};
 if (!ext || !mime) throw new Error("Cannot detect file type");

 const formData = new FormData();
 formData.append("files[]", buffer, {
 filename: `file-${Date.now()}.${ext}`,
 contentType: mime,
 });

 const response = await fetch("https://up1.fileditch.com/upload.php", {
 method: "POST",
 body: formData,
 headers: {
 "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
 ...formData.getHeaders(),
 },
 });

 if (!response.ok) {
 const errorText = await response.text();
 throw new Error(`Upload failed with status ${response.status}: ${errorText}`);
 }

 const files = await response.json();
 if (!files.files || !files.files[0] || !files.files[0].url) {
 throw new Error("Failed to retrieve file URL");
 }

 return files.files[0].url;
 } catch (error) {
 throw new Error(`Upload failed: ${error.message}`);
 }
 }

 try {
 m.reply('Sedang memuat...');

 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 if (fs.statSync(media).size > 350000000) {
 m.reply('File terlalu besar, maksimal 350MB');
 return;
 }

 let url = await fileDitch(media);
 m.reply(`Link: ${url}`);

 fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Terjadi kesalahan saat mengunggah file: ${err.message}`);
 }
}
break

case 'qc5': {
 try {
 const { TelegraPh } = require('./lib/uploader');
 const axios = require('axios');
 const fs = require('fs');
 const exec = require('child_process').exec;

 // Fungsi untuk memilih item acak dari array
 function pickRandom(arr) {
 return arr[Math.floor(Math.random() * arr.length)];
 }

 // Warna acak untuk latar belakang
 const randomColor = ['#ef1a11', '#89cff0', '#660000', '#87a96b', '#e9f6ff', '#ffe7f7', '#ca86b0', '#83a3ee', '#abcc88', '#80bd76', '#6a84bd', '#5d8d7f', '#530101', '#863434', '#013337', '#133700', '#2f3641', '#cc4291', '#7c4848', '#8a496b', '#722f37', '#0fc163', '#2f3641', '#e7a6cb', '#64c987', '#e6e6fa'];
 const apiColor = pickRandom(randomColor);

 // Mendapatkan pengirim dan nama
 const dia = (m.quoted?.text ? m.quoted : m).sender;
 const name = await sky.getName(dia);

 // Mendapatkan teks dari pesan yang dikutip atau input
 let teks = m.quoted ? m.quoted.text : q ? q : "";

 // Mendapatkan avatar
 const avatar = await sky.profilePictureUrl(dia, "image").catch(_ => "https://telegra.ph/file/89c1638d9620584e6e140.png");

 // Memeriksa apakah pesan atau pesan yang dikutip berisi gambar atau stiker
 const isImage = m.mtype === 'imageMessage';
 const isQuotedImage = m.quoted && m.quoted.mtype === 'imageMessage';
 const isQuotedSticker = m.quoted && m.quoted.mtype === 'stickerMessage';

 if (isImage || isQuotedImage) {
 // Menangani pesan gambar
 let media = await sky.downloadAndSaveMediaMessage(isQuotedImage ? m.quoted : m, 'temp');
 let anu = await TelegraPh(media);
 const json = {
 type: "quote",
 format: "png",
 backgroundColor: apiColor,
 width: 512,
 height: 768,
 scale: 2,
 messages: [{
 entities: [],
 media: { url: anu },
 avatar: true,
 from: {
 id: pickRandom([0, 4, 5, 3, 2, 7, 5, 9, 8, 1, 6, 10, 9, 7, 5, 3, 1, 2, 4, 6, 8, 0, 10]),
 name,
 photo: { url: avatar }
 },
 text: `${teks}`,
 replyMessage: {}
 }]
 };
 const { data } = await axios.post("https://quotly.netorare.codes/generate", json, {
 headers: { "Content-Type": "application/json" }
 }).catch(e => e.response || {});
 if (!data.ok) throw data;
 const buffer = Buffer.from(data.result.image, "base64");
 const filePath = 'temp.png';
 fs.writeFileSync(filePath, buffer);
 await sky.sendImageAsSticker(m.chat, filePath, m, { packname: global.packname, author: global.author });
 fs.unlinkSync(media);
 fs.unlinkSync(filePath);
 } else if (isQuotedSticker) {
 // Menangani pesan stiker yang dikutip
 let media = await sky.downloadAndSaveMediaMessage(m.quoted, 'temp');
 const filePath = 'temp.png';
 exec(`ffmpeg -i ${media} -vf "fps=10,scale=512:512:flags=lanczos" -t 3 ${filePath}`, async (err) => {
 fs.unlinkSync(media);
 if (err) return m.reply(err);
 let anuah = await TelegraPh(filePath);
 const json = {
 type: "quote",
 format: "png",
 backgroundColor: apiColor,
 width: 512,
 height: 768,
 scale: 2,
 messages: [{
 entities: [],
 media: { url: anuah },
 avatar: true,
 from: {
 id: pickRandom([0, 4, 5, 3, 2, 7, 5, 9, 8, 1, 6, 10, 9, 7, 5, 3, 1, 2, 4, 6, 8, 0, 10]),
 name,
 photo: { url: avatar }
 },
 text: `${teks}`,
 replyMessage: {}
 }]
 };
 const { data } = await axios.post("https://quotly.netorare.codes/generate", json, {
 headers: { "Content-Type": "application/json" }
 }).catch(e => e.response || {});
 if (!data.ok) throw data;
 const buffer = Buffer.from(data.result.image, "base64");
 fs.writeFileSync(filePath, buffer);
 await sky.sendImageAsSticker(m.chat, filePath, m, { packname: global.packname, author: global.author });
 fs.unlinkSync(filePath);
 });
 } else {
 // Menangani pesan teks
 const json = {
 type: "quote",
 format: "png",
 backgroundColor: apiColor,
 width: 512,
 height: 768,
 scale: 2,
 messages: [{
 entities: [],
 avatar: true,
 from: {
 id: pickRandom([0, 4, 5, 3, 2, 7, 5, 9, 8, 1, 6, 10, 9, 7, 5, 3, 1, 2, 4, 6, 8, 0, 10]),
 name,
 photo: { url: avatar }
 },
 text: `${teks}`,
 replyMessage: {}
 }]
 };
 const { data } = await axios.post("https://quotly.netorare.codes/generate", json, {
 headers: { "Content-Type": "application/json" }
 }).catch(e => e.response || {});
 if (!data.ok) m.reply(data);
 const buffer = Buffer.from(data.result.image, "base64");
 const filePath = 'temp.png';
 fs.writeFileSync(filePath, buffer);
 await sky.sendImageAsSticker(m.chat, filePath, m, { packname: global.packname, author: global.author });
 fs.unlinkSync(filePath);
 }
 } catch (e) {
 m.reply('sistem eror coba lagi nanti');
 console.log(e);
 return;
 }
}
break
case 'ai8': {
 if (!m.quoted || !m.quoted.text) {
 return m.reply("Reply Teks untuk menggunakan gpt ini");
 }

 const message = m.quoted.text;

 async function gptChat(message) {
 try {
 const info = await getInfo(),
 data = new FormData();
 data.append("_wpnonce", info[0]["data-nonce"]);
 data.append("post_id", info[0]["data-post-id"]);
 data.append("action", "wpaicg_chatbox_message");
 data.append("message", message);
 const response = await fetch("https://bardaifree.com/wp-admin/admin-ajax.php", {
 method: "POST",
 body: data
 });
 if (!response.ok) throw new Error("Network response was not ok");
 return await response.json();
 } catch (error) {
 throw console.error("An error occurred:", error.message), error;
 }
 }

 async function getInfo() {
 try {
 const html = await (await fetch("https://bardaifree.com")).text(),
 $ = cheerio.load(html);
 return $(".wpaicg-chat-shortcode").map((index, element) => Object.fromEntries(Object.entries(element.attribs))).get();
 } catch (error) {
 throw new Error("Error:", error.message);
 }
 }

 (async () => {
 try {
 const response = await gptChat(message);
 if (response.status === 'success') {
 m.reply(response.data);
 } else {
 m.reply("Terjadi kesalahan saat memproses permintaan.");
 }
 } catch (error) {
 m.reply("Terjadi kesalahan saat memproses permintaan.");
 }
 })();
}
break
//ADDF	    
            default:
                if (budy.startsWith('=👉')) {
                    if (!isCreator) return m.reply(mess.owner)
                    function Return(sul) {
                        sat = JSON.stringify(sul, null, 2)
                        bang = util.format(sat)
                            if (sat == undefined) {
                                bang = util.format(sul)
                            }
                            return m.reply(bang)
                    }
                    try {
                        m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
                    } catch (e) {
                        m.reply(String(e))
                    }
                }

                if (budy.startsWith('👉')) {
                    if (!isCreator) return m.reply(mess.owner)
                    try {
                        let evaled = await eval(budy.slice(2))
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                        await m.reply(evaled)
                    } catch (err) {
                        await m.reply(String(err))
                    }
                }

                if (budy.startsWith('💲')) {
                    if (!isCreator) return m.reply(mess.owner)
                    exec(budy.slice(2), (err, stdout) => {
                        if (err) return m.reply(`${err}`)
                        if (stdout) return m.reply(stdout)
                    })
                }			
                        }
} catch (err) {

        m.reply(util.format(err))

    }
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})